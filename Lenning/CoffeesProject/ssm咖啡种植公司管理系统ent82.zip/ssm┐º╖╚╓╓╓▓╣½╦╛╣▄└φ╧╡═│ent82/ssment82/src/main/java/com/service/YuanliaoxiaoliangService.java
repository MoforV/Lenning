package com.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.utils.PageUtils;
import com.entity.YuanliaoxiaoliangEntity;
import java.util.List;
import java.util.Map;
import com.entity.vo.YuanliaoxiaoliangVO;
import org.apache.ibatis.annotations.Param;
import com.entity.view.YuanliaoxiaoliangView;


/**
 * 原料销量
 *
 * @author 
 * @email 
 * @date 2022-08-06 14:28:54
 */
public interface YuanliaoxiaoliangService extends IService<YuanliaoxiaoliangEntity> {

    PageUtils queryPage(Map<String, Object> params);
    
   	List<YuanliaoxiaoliangVO> selectListVO(Wrapper<YuanliaoxiaoliangEntity> wrapper);
   	
   	YuanliaoxiaoliangVO selectVO(@Param("ew") Wrapper<YuanliaoxiaoliangEntity> wrapper);
   	
   	List<YuanliaoxiaoliangView> selectListView(Wrapper<YuanliaoxiaoliangEntity> wrapper);
   	
   	YuanliaoxiaoliangView selectView(@Param("ew") Wrapper<YuanliaoxiaoliangEntity> wrapper);
   	
   	PageUtils queryPage(Map<String, Object> params,Wrapper<YuanliaoxiaoliangEntity> wrapper);
   	

}

