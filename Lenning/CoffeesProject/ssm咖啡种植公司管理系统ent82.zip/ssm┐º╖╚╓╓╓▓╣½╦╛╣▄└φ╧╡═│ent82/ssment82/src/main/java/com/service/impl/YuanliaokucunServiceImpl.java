package com.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.List;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.utils.PageUtils;
import com.utils.Query;


import com.dao.YuanliaokucunDao;
import com.entity.YuanliaokucunEntity;
import com.service.YuanliaokucunService;
import com.entity.vo.YuanliaokucunVO;
import com.entity.view.YuanliaokucunView;

@Service("yuanliaokucunService")
public class YuanliaokucunServiceImpl extends ServiceImpl<YuanliaokucunDao, YuanliaokucunEntity> implements YuanliaokucunService {
	

    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        Page<YuanliaokucunEntity> page = this.selectPage(
                new Query<YuanliaokucunEntity>(params).getPage(),
                new EntityWrapper<YuanliaokucunEntity>()
        );
        return new PageUtils(page);
    }
    
    @Override
	public PageUtils queryPage(Map<String, Object> params, Wrapper<YuanliaokucunEntity> wrapper) {
		  Page<YuanliaokucunView> page =new Query<YuanliaokucunView>(params).getPage();
	        page.setRecords(baseMapper.selectListView(page,wrapper));
	    	PageUtils pageUtil = new PageUtils(page);
	    	return pageUtil;
 	}
    
    @Override
	public List<YuanliaokucunVO> selectListVO(Wrapper<YuanliaokucunEntity> wrapper) {
 		return baseMapper.selectListVO(wrapper);
	}
	
	@Override
	public YuanliaokucunVO selectVO(Wrapper<YuanliaokucunEntity> wrapper) {
 		return baseMapper.selectVO(wrapper);
	}
	
	@Override
	public List<YuanliaokucunView> selectListView(Wrapper<YuanliaokucunEntity> wrapper) {
		return baseMapper.selectListView(wrapper);
	}

	@Override
	public YuanliaokucunView selectView(Wrapper<YuanliaokucunEntity> wrapper) {
		return baseMapper.selectView(wrapper);
	}


}
