package com.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.utils.PageUtils;
import com.entity.FeiliaokucunEntity;
import java.util.List;
import java.util.Map;
import com.entity.vo.FeiliaokucunVO;
import org.apache.ibatis.annotations.Param;
import com.entity.view.FeiliaokucunView;


/**
 * 肥料库存
 *
 * @author 
 * @email 
 * @date 2022-08-06 14:28:54
 */
public interface FeiliaokucunService extends IService<FeiliaokucunEntity> {

    PageUtils queryPage(Map<String, Object> params);
    
   	List<FeiliaokucunVO> selectListVO(Wrapper<FeiliaokucunEntity> wrapper);
   	
   	FeiliaokucunVO selectVO(@Param("ew") Wrapper<FeiliaokucunEntity> wrapper);
   	
   	List<FeiliaokucunView> selectListView(Wrapper<FeiliaokucunEntity> wrapper);
   	
   	FeiliaokucunView selectView(@Param("ew") Wrapper<FeiliaokucunEntity> wrapper);
   	
   	PageUtils queryPage(Map<String, Object> params,Wrapper<FeiliaokucunEntity> wrapper);
   	

}

