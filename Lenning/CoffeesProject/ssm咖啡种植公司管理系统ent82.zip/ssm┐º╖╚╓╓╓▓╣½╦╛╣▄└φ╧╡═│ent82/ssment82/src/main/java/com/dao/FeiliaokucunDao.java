package com.dao;

import com.entity.FeiliaokucunEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.entity.vo.FeiliaokucunVO;
import com.entity.view.FeiliaokucunView;


/**
 * 肥料库存
 * 
 * @author 
 * @email 
 * @date 2022-08-06 14:28:54
 */
public interface FeiliaokucunDao extends BaseMapper<FeiliaokucunEntity> {
	
	List<FeiliaokucunVO> selectListVO(@Param("ew") Wrapper<FeiliaokucunEntity> wrapper);
	
	FeiliaokucunVO selectVO(@Param("ew") Wrapper<FeiliaokucunEntity> wrapper);
	
	List<FeiliaokucunView> selectListView(@Param("ew") Wrapper<FeiliaokucunEntity> wrapper);

	List<FeiliaokucunView> selectListView(Pagination page,@Param("ew") Wrapper<FeiliaokucunEntity> wrapper);
	
	FeiliaokucunView selectView(@Param("ew") Wrapper<FeiliaokucunEntity> wrapper);
	

}
