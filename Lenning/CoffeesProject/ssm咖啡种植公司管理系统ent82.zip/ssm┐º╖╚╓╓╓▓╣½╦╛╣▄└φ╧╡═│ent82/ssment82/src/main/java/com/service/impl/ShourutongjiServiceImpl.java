package com.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.List;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.utils.PageUtils;
import com.utils.Query;


import com.dao.ShourutongjiDao;
import com.entity.ShourutongjiEntity;
import com.service.ShourutongjiService;
import com.entity.vo.ShourutongjiVO;
import com.entity.view.ShourutongjiView;

@Service("shourutongjiService")
public class ShourutongjiServiceImpl extends ServiceImpl<ShourutongjiDao, ShourutongjiEntity> implements ShourutongjiService {
	

    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        Page<ShourutongjiEntity> page = this.selectPage(
                new Query<ShourutongjiEntity>(params).getPage(),
                new EntityWrapper<ShourutongjiEntity>()
        );
        return new PageUtils(page);
    }
    
    @Override
	public PageUtils queryPage(Map<String, Object> params, Wrapper<ShourutongjiEntity> wrapper) {
		  Page<ShourutongjiView> page =new Query<ShourutongjiView>(params).getPage();
	        page.setRecords(baseMapper.selectListView(page,wrapper));
	    	PageUtils pageUtil = new PageUtils(page);
	    	return pageUtil;
 	}
    
    @Override
	public List<ShourutongjiVO> selectListVO(Wrapper<ShourutongjiEntity> wrapper) {
 		return baseMapper.selectListVO(wrapper);
	}
	
	@Override
	public ShourutongjiVO selectVO(Wrapper<ShourutongjiEntity> wrapper) {
 		return baseMapper.selectVO(wrapper);
	}
	
	@Override
	public List<ShourutongjiView> selectListView(Wrapper<ShourutongjiEntity> wrapper) {
		return baseMapper.selectListView(wrapper);
	}

	@Override
	public ShourutongjiView selectView(Wrapper<ShourutongjiEntity> wrapper) {
		return baseMapper.selectView(wrapper);
	}

    @Override
    public List<Map<String, Object>> selectValue(Map<String, Object> params, Wrapper<ShourutongjiEntity> wrapper) {
        return baseMapper.selectValue(params, wrapper);
    }

    @Override
    public List<Map<String, Object>> selectTimeStatValue(Map<String, Object> params, Wrapper<ShourutongjiEntity> wrapper) {
        return baseMapper.selectTimeStatValue(params, wrapper);
    }

    @Override
    public List<Map<String, Object>> selectGroup(Map<String, Object> params, Wrapper<ShourutongjiEntity> wrapper) {
        return baseMapper.selectGroup(params, wrapper);
    }

}
