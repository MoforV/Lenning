package com.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.List;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.utils.PageUtils;
import com.utils.Query;


import com.dao.ZhongzhishujuDao;
import com.entity.ZhongzhishujuEntity;
import com.service.ZhongzhishujuService;
import com.entity.vo.ZhongzhishujuVO;
import com.entity.view.ZhongzhishujuView;

@Service("zhongzhishujuService")
public class ZhongzhishujuServiceImpl extends ServiceImpl<ZhongzhishujuDao, ZhongzhishujuEntity> implements ZhongzhishujuService {
	

    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        Page<ZhongzhishujuEntity> page = this.selectPage(
                new Query<ZhongzhishujuEntity>(params).getPage(),
                new EntityWrapper<ZhongzhishujuEntity>()
        );
        return new PageUtils(page);
    }
    
    @Override
	public PageUtils queryPage(Map<String, Object> params, Wrapper<ZhongzhishujuEntity> wrapper) {
		  Page<ZhongzhishujuView> page =new Query<ZhongzhishujuView>(params).getPage();
	        page.setRecords(baseMapper.selectListView(page,wrapper));
	    	PageUtils pageUtil = new PageUtils(page);
	    	return pageUtil;
 	}
    
    @Override
	public List<ZhongzhishujuVO> selectListVO(Wrapper<ZhongzhishujuEntity> wrapper) {
 		return baseMapper.selectListVO(wrapper);
	}
	
	@Override
	public ZhongzhishujuVO selectVO(Wrapper<ZhongzhishujuEntity> wrapper) {
 		return baseMapper.selectVO(wrapper);
	}
	
	@Override
	public List<ZhongzhishujuView> selectListView(Wrapper<ZhongzhishujuEntity> wrapper) {
		return baseMapper.selectListView(wrapper);
	}

	@Override
	public ZhongzhishujuView selectView(Wrapper<ZhongzhishujuEntity> wrapper) {
		return baseMapper.selectView(wrapper);
	}


}
