package com.entity.vo;

import com.entity.BanchengpinxiaoliangEntity;

import com.baomidou.mybatisplus.annotations.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
 

/**
 * 半成品销量
 * 手机端接口返回实体辅助类 
 * （主要作用去除一些不必要的字段）
 * @author 
 * @email 
 * @date 2022-08-06 14:28:54
 */
public class BanchengpinxiaoliangVO  implements Serializable {
	private static final long serialVersionUID = 1L;

	 			
	/**
	 * 成品名称
	 */
	
	private String chengpinmingcheng;
		
	/**
	 * 成品销量
	 */
	
	private Integer chengpinxiaoliang;
		
	/**
	 * 登记日期
	 */
		
	@JsonFormat(locale="zh", timezone="GMT+8", pattern="yyyy-MM-dd HH:mm:ss")
	@DateTimeFormat 
	private Date dengjiriqi;
		
	/**
	 * 备注
	 */
	
	private String beizhu;
				
	
	/**
	 * 设置：成品名称
	 */
	 
	public void setChengpinmingcheng(String chengpinmingcheng) {
		this.chengpinmingcheng = chengpinmingcheng;
	}
	
	/**
	 * 获取：成品名称
	 */
	public String getChengpinmingcheng() {
		return chengpinmingcheng;
	}
				
	
	/**
	 * 设置：成品销量
	 */
	 
	public void setChengpinxiaoliang(Integer chengpinxiaoliang) {
		this.chengpinxiaoliang = chengpinxiaoliang;
	}
	
	/**
	 * 获取：成品销量
	 */
	public Integer getChengpinxiaoliang() {
		return chengpinxiaoliang;
	}
				
	
	/**
	 * 设置：登记日期
	 */
	 
	public void setDengjiriqi(Date dengjiriqi) {
		this.dengjiriqi = dengjiriqi;
	}
	
	/**
	 * 获取：登记日期
	 */
	public Date getDengjiriqi() {
		return dengjiriqi;
	}
				
	
	/**
	 * 设置：备注
	 */
	 
	public void setBeizhu(String beizhu) {
		this.beizhu = beizhu;
	}
	
	/**
	 * 获取：备注
	 */
	public String getBeizhu() {
		return beizhu;
	}
			
}
