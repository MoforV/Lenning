package com.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.List;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.utils.PageUtils;
import com.utils.Query;


import com.dao.ZhongzhifanganDao;
import com.entity.ZhongzhifanganEntity;
import com.service.ZhongzhifanganService;
import com.entity.vo.ZhongzhifanganVO;
import com.entity.view.ZhongzhifanganView;

@Service("zhongzhifanganService")
public class ZhongzhifanganServiceImpl extends ServiceImpl<ZhongzhifanganDao, ZhongzhifanganEntity> implements ZhongzhifanganService {
	

    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        Page<ZhongzhifanganEntity> page = this.selectPage(
                new Query<ZhongzhifanganEntity>(params).getPage(),
                new EntityWrapper<ZhongzhifanganEntity>()
        );
        return new PageUtils(page);
    }
    
    @Override
	public PageUtils queryPage(Map<String, Object> params, Wrapper<ZhongzhifanganEntity> wrapper) {
		  Page<ZhongzhifanganView> page =new Query<ZhongzhifanganView>(params).getPage();
	        page.setRecords(baseMapper.selectListView(page,wrapper));
	    	PageUtils pageUtil = new PageUtils(page);
	    	return pageUtil;
 	}
    
    @Override
	public List<ZhongzhifanganVO> selectListVO(Wrapper<ZhongzhifanganEntity> wrapper) {
 		return baseMapper.selectListVO(wrapper);
	}
	
	@Override
	public ZhongzhifanganVO selectVO(Wrapper<ZhongzhifanganEntity> wrapper) {
 		return baseMapper.selectVO(wrapper);
	}
	
	@Override
	public List<ZhongzhifanganView> selectListView(Wrapper<ZhongzhifanganEntity> wrapper) {
		return baseMapper.selectListView(wrapper);
	}

	@Override
	public ZhongzhifanganView selectView(Wrapper<ZhongzhifanganEntity> wrapper) {
		return baseMapper.selectView(wrapper);
	}


}
