package com.entity.vo;

import com.entity.XinxitongjiEntity;

import com.baomidou.mybatisplus.annotations.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
 

/**
 * 信息统计
 * 手机端接口返回实体辅助类 
 * （主要作用去除一些不必要的字段）
 * @author 
 * @email 
 * @date 2022-08-06 14:28:54
 */
public class XinxitongjiVO  implements Serializable {
	private static final long serialVersionUID = 1L;

	 			
	/**
	 * 基地名称
	 */
	
	private String jidimingcheng;
		
	/**
	 * 基地面积
	 */
	
	private String jidimianji;
		
	/**
	 * 种植数量
	 */
	
	private Integer zhongzhishuliang;
		
	/**
	 * 登记日期
	 */
		
	@JsonFormat(locale="zh", timezone="GMT+8", pattern="yyyy-MM-dd HH:mm:ss")
	@DateTimeFormat 
	private Date dengjiriqi;
		
	/**
	 * 备注
	 */
	
	private String beizhu;
				
	
	/**
	 * 设置：基地名称
	 */
	 
	public void setJidimingcheng(String jidimingcheng) {
		this.jidimingcheng = jidimingcheng;
	}
	
	/**
	 * 获取：基地名称
	 */
	public String getJidimingcheng() {
		return jidimingcheng;
	}
				
	
	/**
	 * 设置：基地面积
	 */
	 
	public void setJidimianji(String jidimianji) {
		this.jidimianji = jidimianji;
	}
	
	/**
	 * 获取：基地面积
	 */
	public String getJidimianji() {
		return jidimianji;
	}
				
	
	/**
	 * 设置：种植数量
	 */
	 
	public void setZhongzhishuliang(Integer zhongzhishuliang) {
		this.zhongzhishuliang = zhongzhishuliang;
	}
	
	/**
	 * 获取：种植数量
	 */
	public Integer getZhongzhishuliang() {
		return zhongzhishuliang;
	}
				
	
	/**
	 * 设置：登记日期
	 */
	 
	public void setDengjiriqi(Date dengjiriqi) {
		this.dengjiriqi = dengjiriqi;
	}
	
	/**
	 * 获取：登记日期
	 */
	public Date getDengjiriqi() {
		return dengjiriqi;
	}
				
	
	/**
	 * 设置：备注
	 */
	 
	public void setBeizhu(String beizhu) {
		this.beizhu = beizhu;
	}
	
	/**
	 * 获取：备注
	 */
	public String getBeizhu() {
		return beizhu;
	}
			
}
