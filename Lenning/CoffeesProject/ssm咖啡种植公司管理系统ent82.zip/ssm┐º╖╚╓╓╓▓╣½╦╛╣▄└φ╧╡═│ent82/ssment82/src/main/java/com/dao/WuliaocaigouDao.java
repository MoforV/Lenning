package com.dao;

import com.entity.WuliaocaigouEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.entity.vo.WuliaocaigouVO;
import com.entity.view.WuliaocaigouView;


/**
 * 物料采购
 * 
 * @author 
 * @email 
 * @date 2022-08-06 14:28:54
 */
public interface WuliaocaigouDao extends BaseMapper<WuliaocaigouEntity> {
	
	List<WuliaocaigouVO> selectListVO(@Param("ew") Wrapper<WuliaocaigouEntity> wrapper);
	
	WuliaocaigouVO selectVO(@Param("ew") Wrapper<WuliaocaigouEntity> wrapper);
	
	List<WuliaocaigouView> selectListView(@Param("ew") Wrapper<WuliaocaigouEntity> wrapper);

	List<WuliaocaigouView> selectListView(Pagination page,@Param("ew") Wrapper<WuliaocaigouEntity> wrapper);
	
	WuliaocaigouView selectView(@Param("ew") Wrapper<WuliaocaigouEntity> wrapper);
	

}
