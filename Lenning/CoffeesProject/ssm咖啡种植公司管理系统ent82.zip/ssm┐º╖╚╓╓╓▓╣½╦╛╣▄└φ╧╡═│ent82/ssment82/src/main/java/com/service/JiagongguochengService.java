package com.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.utils.PageUtils;
import com.entity.JiagongguochengEntity;
import java.util.List;
import java.util.Map;
import com.entity.vo.JiagongguochengVO;
import org.apache.ibatis.annotations.Param;
import com.entity.view.JiagongguochengView;


/**
 * 加工过程
 *
 * @author 
 * @email 
 * @date 2022-08-06 14:28:54
 */
public interface JiagongguochengService extends IService<JiagongguochengEntity> {

    PageUtils queryPage(Map<String, Object> params);
    
   	List<JiagongguochengVO> selectListVO(Wrapper<JiagongguochengEntity> wrapper);
   	
   	JiagongguochengVO selectVO(@Param("ew") Wrapper<JiagongguochengEntity> wrapper);
   	
   	List<JiagongguochengView> selectListView(Wrapper<JiagongguochengEntity> wrapper);
   	
   	JiagongguochengView selectView(@Param("ew") Wrapper<JiagongguochengEntity> wrapper);
   	
   	PageUtils queryPage(Map<String, Object> params,Wrapper<JiagongguochengEntity> wrapper);
   	

}

