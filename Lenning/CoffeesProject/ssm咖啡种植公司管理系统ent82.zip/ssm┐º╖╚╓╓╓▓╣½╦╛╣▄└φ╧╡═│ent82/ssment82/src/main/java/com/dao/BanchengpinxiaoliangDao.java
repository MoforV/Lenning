package com.dao;

import com.entity.BanchengpinxiaoliangEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.entity.vo.BanchengpinxiaoliangVO;
import com.entity.view.BanchengpinxiaoliangView;


/**
 * 半成品销量
 * 
 * @author 
 * @email 
 * @date 2022-08-06 14:28:54
 */
public interface BanchengpinxiaoliangDao extends BaseMapper<BanchengpinxiaoliangEntity> {
	
	List<BanchengpinxiaoliangVO> selectListVO(@Param("ew") Wrapper<BanchengpinxiaoliangEntity> wrapper);
	
	BanchengpinxiaoliangVO selectVO(@Param("ew") Wrapper<BanchengpinxiaoliangEntity> wrapper);
	
	List<BanchengpinxiaoliangView> selectListView(@Param("ew") Wrapper<BanchengpinxiaoliangEntity> wrapper);

	List<BanchengpinxiaoliangView> selectListView(Pagination page,@Param("ew") Wrapper<BanchengpinxiaoliangEntity> wrapper);
	
	BanchengpinxiaoliangView selectView(@Param("ew") Wrapper<BanchengpinxiaoliangEntity> wrapper);
	

}
