package com.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.utils.PageUtils;
import com.entity.ChengpinkucunEntity;
import java.util.List;
import java.util.Map;
import com.entity.vo.ChengpinkucunVO;
import org.apache.ibatis.annotations.Param;
import com.entity.view.ChengpinkucunView;


/**
 * 成品库存
 *
 * @author 
 * @email 
 * @date 2022-08-06 14:28:54
 */
public interface ChengpinkucunService extends IService<ChengpinkucunEntity> {

    PageUtils queryPage(Map<String, Object> params);
    
   	List<ChengpinkucunVO> selectListVO(Wrapper<ChengpinkucunEntity> wrapper);
   	
   	ChengpinkucunVO selectVO(@Param("ew") Wrapper<ChengpinkucunEntity> wrapper);
   	
   	List<ChengpinkucunView> selectListView(Wrapper<ChengpinkucunEntity> wrapper);
   	
   	ChengpinkucunView selectView(@Param("ew") Wrapper<ChengpinkucunEntity> wrapper);
   	
   	PageUtils queryPage(Map<String, Object> params,Wrapper<ChengpinkucunEntity> wrapper);
   	

}

