package com.dao;

import com.entity.YuanliaokucunEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.entity.vo.YuanliaokucunVO;
import com.entity.view.YuanliaokucunView;


/**
 * 原料库存
 * 
 * @author 
 * @email 
 * @date 2022-08-06 14:28:54
 */
public interface YuanliaokucunDao extends BaseMapper<YuanliaokucunEntity> {
	
	List<YuanliaokucunVO> selectListVO(@Param("ew") Wrapper<YuanliaokucunEntity> wrapper);
	
	YuanliaokucunVO selectVO(@Param("ew") Wrapper<YuanliaokucunEntity> wrapper);
	
	List<YuanliaokucunView> selectListView(@Param("ew") Wrapper<YuanliaokucunEntity> wrapper);

	List<YuanliaokucunView> selectListView(Pagination page,@Param("ew") Wrapper<YuanliaokucunEntity> wrapper);
	
	YuanliaokucunView selectView(@Param("ew") Wrapper<YuanliaokucunEntity> wrapper);
	

}
