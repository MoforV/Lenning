package com.dao;

import com.entity.ChengpinkucunEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.entity.vo.ChengpinkucunVO;
import com.entity.view.ChengpinkucunView;


/**
 * 成品库存
 * 
 * @author 
 * @email 
 * @date 2022-08-06 14:28:54
 */
public interface ChengpinkucunDao extends BaseMapper<ChengpinkucunEntity> {
	
	List<ChengpinkucunVO> selectListVO(@Param("ew") Wrapper<ChengpinkucunEntity> wrapper);
	
	ChengpinkucunVO selectVO(@Param("ew") Wrapper<ChengpinkucunEntity> wrapper);
	
	List<ChengpinkucunView> selectListView(@Param("ew") Wrapper<ChengpinkucunEntity> wrapper);

	List<ChengpinkucunView> selectListView(Pagination page,@Param("ew") Wrapper<ChengpinkucunEntity> wrapper);
	
	ChengpinkucunView selectView(@Param("ew") Wrapper<ChengpinkucunEntity> wrapper);
	

}
