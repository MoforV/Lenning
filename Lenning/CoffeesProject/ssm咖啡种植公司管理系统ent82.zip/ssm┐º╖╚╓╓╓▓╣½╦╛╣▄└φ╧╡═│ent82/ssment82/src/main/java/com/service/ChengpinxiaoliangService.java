package com.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.utils.PageUtils;
import com.entity.ChengpinxiaoliangEntity;
import java.util.List;
import java.util.Map;
import com.entity.vo.ChengpinxiaoliangVO;
import org.apache.ibatis.annotations.Param;
import com.entity.view.ChengpinxiaoliangView;


/**
 * 成品销量
 *
 * @author 
 * @email 
 * @date 2022-08-06 14:28:54
 */
public interface ChengpinxiaoliangService extends IService<ChengpinxiaoliangEntity> {

    PageUtils queryPage(Map<String, Object> params);
    
   	List<ChengpinxiaoliangVO> selectListVO(Wrapper<ChengpinxiaoliangEntity> wrapper);
   	
   	ChengpinxiaoliangVO selectVO(@Param("ew") Wrapper<ChengpinxiaoliangEntity> wrapper);
   	
   	List<ChengpinxiaoliangView> selectListView(Wrapper<ChengpinxiaoliangEntity> wrapper);
   	
   	ChengpinxiaoliangView selectView(@Param("ew") Wrapper<ChengpinxiaoliangEntity> wrapper);
   	
   	PageUtils queryPage(Map<String, Object> params,Wrapper<ChengpinxiaoliangEntity> wrapper);
   	

}

