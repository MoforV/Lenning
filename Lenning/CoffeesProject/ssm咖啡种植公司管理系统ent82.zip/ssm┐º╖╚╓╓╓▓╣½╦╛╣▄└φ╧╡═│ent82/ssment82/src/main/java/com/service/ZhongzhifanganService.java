package com.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.utils.PageUtils;
import com.entity.ZhongzhifanganEntity;
import java.util.List;
import java.util.Map;
import com.entity.vo.ZhongzhifanganVO;
import org.apache.ibatis.annotations.Param;
import com.entity.view.ZhongzhifanganView;


/**
 * 种植方案
 *
 * @author 
 * @email 
 * @date 2022-08-06 14:28:54
 */
public interface ZhongzhifanganService extends IService<ZhongzhifanganEntity> {

    PageUtils queryPage(Map<String, Object> params);
    
   	List<ZhongzhifanganVO> selectListVO(Wrapper<ZhongzhifanganEntity> wrapper);
   	
   	ZhongzhifanganVO selectVO(@Param("ew") Wrapper<ZhongzhifanganEntity> wrapper);
   	
   	List<ZhongzhifanganView> selectListView(Wrapper<ZhongzhifanganEntity> wrapper);
   	
   	ZhongzhifanganView selectView(@Param("ew") Wrapper<ZhongzhifanganEntity> wrapper);
   	
   	PageUtils queryPage(Map<String, Object> params,Wrapper<ZhongzhifanganEntity> wrapper);
   	

}

