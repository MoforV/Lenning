package com.entity.view;

import com.entity.NongyaokucunEntity;

import com.baomidou.mybatisplus.annotations.TableName;
import org.apache.commons.beanutils.BeanUtils;
import java.lang.reflect.InvocationTargetException;

import java.io.Serializable;
 

/**
 * 农药库存
 * 后端返回视图实体辅助类   
 * （通常后端关联的表或者自定义的字段需要返回使用）
 * @author 
 * @email 
 * @date 2022-08-06 14:28:54
 */
@TableName("nongyaokucun")
public class NongyaokucunView  extends NongyaokucunEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	public NongyaokucunView(){
	}
 
 	public NongyaokucunView(NongyaokucunEntity nongyaokucunEntity){
 	try {
			BeanUtils.copyProperties(this, nongyaokucunEntity);
		} catch (IllegalAccessException | InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
 		
	}
}
