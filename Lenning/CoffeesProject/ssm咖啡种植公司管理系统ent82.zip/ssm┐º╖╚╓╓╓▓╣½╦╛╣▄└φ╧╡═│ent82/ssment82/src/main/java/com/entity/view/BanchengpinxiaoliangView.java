package com.entity.view;

import com.entity.BanchengpinxiaoliangEntity;

import com.baomidou.mybatisplus.annotations.TableName;
import org.apache.commons.beanutils.BeanUtils;
import java.lang.reflect.InvocationTargetException;

import java.io.Serializable;
 

/**
 * 半成品销量
 * 后端返回视图实体辅助类   
 * （通常后端关联的表或者自定义的字段需要返回使用）
 * @author 
 * @email 
 * @date 2022-08-06 14:28:54
 */
@TableName("banchengpinxiaoliang")
public class BanchengpinxiaoliangView  extends BanchengpinxiaoliangEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	public BanchengpinxiaoliangView(){
	}
 
 	public BanchengpinxiaoliangView(BanchengpinxiaoliangEntity banchengpinxiaoliangEntity){
 	try {
			BeanUtils.copyProperties(this, banchengpinxiaoliangEntity);
		} catch (IllegalAccessException | InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
 		
	}
}
