package com.entity.vo;

import com.entity.FeiliaokucunEntity;

import com.baomidou.mybatisplus.annotations.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
 

/**
 * 肥料库存
 * 手机端接口返回实体辅助类 
 * （主要作用去除一些不必要的字段）
 * @author 
 * @email 
 * @date 2022-08-06 14:28:54
 */
public class FeiliaokucunVO  implements Serializable {
	private static final long serialVersionUID = 1L;

	 			
	/**
	 * 肥料名称
	 */
	
	private String feiliaomingcheng;
		
	/**
	 * 肥料类别
	 */
	
	private String feiliaoleibie;
		
	/**
	 * 数量
	 */
	
	private Integer shuliang;
		
	/**
	 * 肥料详情
	 */
	
	private String feiliaoxiangqing;
		
	/**
	 * 登记日期
	 */
		
	@JsonFormat(locale="zh", timezone="GMT+8", pattern="yyyy-MM-dd HH:mm:ss")
	@DateTimeFormat 
	private Date dengjiriqi;
		
	/**
	 * 最近点击时间
	 */
		
	@JsonFormat(locale="zh", timezone="GMT+8", pattern="yyyy-MM-dd HH:mm:ss")
	@DateTimeFormat 
	private Date clicktime;
		
	/**
	 * 点击次数
	 */
	
	private Integer clicknum;
				
	
	/**
	 * 设置：肥料名称
	 */
	 
	public void setFeiliaomingcheng(String feiliaomingcheng) {
		this.feiliaomingcheng = feiliaomingcheng;
	}
	
	/**
	 * 获取：肥料名称
	 */
	public String getFeiliaomingcheng() {
		return feiliaomingcheng;
	}
				
	
	/**
	 * 设置：肥料类别
	 */
	 
	public void setFeiliaoleibie(String feiliaoleibie) {
		this.feiliaoleibie = feiliaoleibie;
	}
	
	/**
	 * 获取：肥料类别
	 */
	public String getFeiliaoleibie() {
		return feiliaoleibie;
	}
				
	
	/**
	 * 设置：数量
	 */
	 
	public void setShuliang(Integer shuliang) {
		this.shuliang = shuliang;
	}
	
	/**
	 * 获取：数量
	 */
	public Integer getShuliang() {
		return shuliang;
	}
				
	
	/**
	 * 设置：肥料详情
	 */
	 
	public void setFeiliaoxiangqing(String feiliaoxiangqing) {
		this.feiliaoxiangqing = feiliaoxiangqing;
	}
	
	/**
	 * 获取：肥料详情
	 */
	public String getFeiliaoxiangqing() {
		return feiliaoxiangqing;
	}
				
	
	/**
	 * 设置：登记日期
	 */
	 
	public void setDengjiriqi(Date dengjiriqi) {
		this.dengjiriqi = dengjiriqi;
	}
	
	/**
	 * 获取：登记日期
	 */
	public Date getDengjiriqi() {
		return dengjiriqi;
	}
				
	
	/**
	 * 设置：最近点击时间
	 */
	 
	public void setClicktime(Date clicktime) {
		this.clicktime = clicktime;
	}
	
	/**
	 * 获取：最近点击时间
	 */
	public Date getClicktime() {
		return clicktime;
	}
				
	
	/**
	 * 设置：点击次数
	 */
	 
	public void setClicknum(Integer clicknum) {
		this.clicknum = clicknum;
	}
	
	/**
	 * 获取：点击次数
	 */
	public Integer getClicknum() {
		return clicknum;
	}
			
}
