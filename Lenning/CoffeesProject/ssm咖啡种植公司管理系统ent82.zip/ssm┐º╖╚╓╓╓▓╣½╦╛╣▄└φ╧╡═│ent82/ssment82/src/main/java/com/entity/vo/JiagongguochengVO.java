package com.entity.vo;

import com.entity.JiagongguochengEntity;

import com.baomidou.mybatisplus.annotations.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
 

/**
 * 加工过程
 * 手机端接口返回实体辅助类 
 * （主要作用去除一些不必要的字段）
 * @author 
 * @email 
 * @date 2022-08-06 14:28:54
 */
public class JiagongguochengVO  implements Serializable {
	private static final long serialVersionUID = 1L;

	 			
	/**
	 * 加工类型
	 */
	
	private String jiagongleixing;
		
	/**
	 * 过程
	 */
	
	private String guocheng;
		
	/**
	 * 登记日期
	 */
		
	@JsonFormat(locale="zh", timezone="GMT+8", pattern="yyyy-MM-dd HH:mm:ss")
	@DateTimeFormat 
	private Date dengjiriqi;
		
	/**
	 * 工号
	 */
	
	private String gonghao;
		
	/**
	 * 姓名
	 */
	
	private String xingming;
				
	
	/**
	 * 设置：加工类型
	 */
	 
	public void setJiagongleixing(String jiagongleixing) {
		this.jiagongleixing = jiagongleixing;
	}
	
	/**
	 * 获取：加工类型
	 */
	public String getJiagongleixing() {
		return jiagongleixing;
	}
				
	
	/**
	 * 设置：过程
	 */
	 
	public void setGuocheng(String guocheng) {
		this.guocheng = guocheng;
	}
	
	/**
	 * 获取：过程
	 */
	public String getGuocheng() {
		return guocheng;
	}
				
	
	/**
	 * 设置：登记日期
	 */
	 
	public void setDengjiriqi(Date dengjiriqi) {
		this.dengjiriqi = dengjiriqi;
	}
	
	/**
	 * 获取：登记日期
	 */
	public Date getDengjiriqi() {
		return dengjiriqi;
	}
				
	
	/**
	 * 设置：工号
	 */
	 
	public void setGonghao(String gonghao) {
		this.gonghao = gonghao;
	}
	
	/**
	 * 获取：工号
	 */
	public String getGonghao() {
		return gonghao;
	}
				
	
	/**
	 * 设置：姓名
	 */
	 
	public void setXingming(String xingming) {
		this.xingming = xingming;
	}
	
	/**
	 * 获取：姓名
	 */
	public String getXingming() {
		return xingming;
	}
			
}
