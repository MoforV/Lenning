package com.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.List;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.utils.PageUtils;
import com.utils.Query;


import com.dao.NongyaokucunDao;
import com.entity.NongyaokucunEntity;
import com.service.NongyaokucunService;
import com.entity.vo.NongyaokucunVO;
import com.entity.view.NongyaokucunView;

@Service("nongyaokucunService")
public class NongyaokucunServiceImpl extends ServiceImpl<NongyaokucunDao, NongyaokucunEntity> implements NongyaokucunService {
	

    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        Page<NongyaokucunEntity> page = this.selectPage(
                new Query<NongyaokucunEntity>(params).getPage(),
                new EntityWrapper<NongyaokucunEntity>()
        );
        return new PageUtils(page);
    }
    
    @Override
	public PageUtils queryPage(Map<String, Object> params, Wrapper<NongyaokucunEntity> wrapper) {
		  Page<NongyaokucunView> page =new Query<NongyaokucunView>(params).getPage();
	        page.setRecords(baseMapper.selectListView(page,wrapper));
	    	PageUtils pageUtil = new PageUtils(page);
	    	return pageUtil;
 	}
    
    @Override
	public List<NongyaokucunVO> selectListVO(Wrapper<NongyaokucunEntity> wrapper) {
 		return baseMapper.selectListVO(wrapper);
	}
	
	@Override
	public NongyaokucunVO selectVO(Wrapper<NongyaokucunEntity> wrapper) {
 		return baseMapper.selectVO(wrapper);
	}
	
	@Override
	public List<NongyaokucunView> selectListView(Wrapper<NongyaokucunEntity> wrapper) {
		return baseMapper.selectListView(wrapper);
	}

	@Override
	public NongyaokucunView selectView(Wrapper<NongyaokucunEntity> wrapper) {
		return baseMapper.selectView(wrapper);
	}


}
