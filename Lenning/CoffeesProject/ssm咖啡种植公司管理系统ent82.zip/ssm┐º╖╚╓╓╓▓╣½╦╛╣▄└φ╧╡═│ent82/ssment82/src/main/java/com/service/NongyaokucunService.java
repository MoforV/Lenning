package com.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.utils.PageUtils;
import com.entity.NongyaokucunEntity;
import java.util.List;
import java.util.Map;
import com.entity.vo.NongyaokucunVO;
import org.apache.ibatis.annotations.Param;
import com.entity.view.NongyaokucunView;


/**
 * 农药库存
 *
 * @author 
 * @email 
 * @date 2022-08-06 14:28:54
 */
public interface NongyaokucunService extends IService<NongyaokucunEntity> {

    PageUtils queryPage(Map<String, Object> params);
    
   	List<NongyaokucunVO> selectListVO(Wrapper<NongyaokucunEntity> wrapper);
   	
   	NongyaokucunVO selectVO(@Param("ew") Wrapper<NongyaokucunEntity> wrapper);
   	
   	List<NongyaokucunView> selectListView(Wrapper<NongyaokucunEntity> wrapper);
   	
   	NongyaokucunView selectView(@Param("ew") Wrapper<NongyaokucunEntity> wrapper);
   	
   	PageUtils queryPage(Map<String, Object> params,Wrapper<NongyaokucunEntity> wrapper);
   	

}

