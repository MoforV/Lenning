package com.dao;

import com.entity.ZhichutongjiEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.entity.vo.ZhichutongjiVO;
import com.entity.view.ZhichutongjiView;


/**
 * 支出统计
 * 
 * @author 
 * @email 
 * @date 2022-08-06 14:28:54
 */
public interface ZhichutongjiDao extends BaseMapper<ZhichutongjiEntity> {
	
	List<ZhichutongjiVO> selectListVO(@Param("ew") Wrapper<ZhichutongjiEntity> wrapper);
	
	ZhichutongjiVO selectVO(@Param("ew") Wrapper<ZhichutongjiEntity> wrapper);
	
	List<ZhichutongjiView> selectListView(@Param("ew") Wrapper<ZhichutongjiEntity> wrapper);

	List<ZhichutongjiView> selectListView(Pagination page,@Param("ew") Wrapper<ZhichutongjiEntity> wrapper);
	
	ZhichutongjiView selectView(@Param("ew") Wrapper<ZhichutongjiEntity> wrapper);
	

    List<Map<String, Object>> selectValue(@Param("params")Map<String, Object> params,@Param("ew") Wrapper<ZhichutongjiEntity> wrapper);

    List<Map<String, Object>> selectTimeStatValue(@Param("params") Map<String, Object> params,@Param("ew") Wrapper<ZhichutongjiEntity> wrapper);

    List<Map<String, Object>> selectGroup(@Param("params") Map<String, Object> params,@Param("ew") Wrapper<ZhichutongjiEntity> wrapper);
}
