package com.dao;

import com.entity.ZhongzhifanganEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.entity.vo.ZhongzhifanganVO;
import com.entity.view.ZhongzhifanganView;


/**
 * 种植方案
 * 
 * @author 
 * @email 
 * @date 2022-08-06 14:28:54
 */
public interface ZhongzhifanganDao extends BaseMapper<ZhongzhifanganEntity> {
	
	List<ZhongzhifanganVO> selectListVO(@Param("ew") Wrapper<ZhongzhifanganEntity> wrapper);
	
	ZhongzhifanganVO selectVO(@Param("ew") Wrapper<ZhongzhifanganEntity> wrapper);
	
	List<ZhongzhifanganView> selectListView(@Param("ew") Wrapper<ZhongzhifanganEntity> wrapper);

	List<ZhongzhifanganView> selectListView(Pagination page,@Param("ew") Wrapper<ZhongzhifanganEntity> wrapper);
	
	ZhongzhifanganView selectView(@Param("ew") Wrapper<ZhongzhifanganEntity> wrapper);
	

}
