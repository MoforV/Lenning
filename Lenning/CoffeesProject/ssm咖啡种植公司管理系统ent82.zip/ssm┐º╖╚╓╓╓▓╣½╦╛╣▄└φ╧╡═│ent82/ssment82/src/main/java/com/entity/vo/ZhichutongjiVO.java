package com.entity.vo;

import com.entity.ZhichutongjiEntity;

import com.baomidou.mybatisplus.annotations.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
 

/**
 * 支出统计
 * 手机端接口返回实体辅助类 
 * （主要作用去除一些不必要的字段）
 * @author 
 * @email 
 * @date 2022-08-06 14:28:54
 */
public class ZhichutongjiVO  implements Serializable {
	private static final long serialVersionUID = 1L;

	 			
	/**
	 * 物料支出
	 */
	
	private Float wuliaozhichu;
		
	/**
	 * 人力支出
	 */
	
	private Float renlizhichu;
		
	/**
	 * 土地租赁
	 */
	
	private Float tudizulin;
		
	/**
	 * 产品加工
	 */
	
	private Float chanpinjiagong;
		
	/**
	 * 其他支出
	 */
	
	private Float qitazhichu;
		
	/**
	 * 总支出
	 */
	
	private Float zongzhichu;
		
	/**
	 * 登记日期
	 */
		
	@JsonFormat(locale="zh", timezone="GMT+8", pattern="yyyy-MM-dd HH:mm:ss")
	@DateTimeFormat 
	private Date dengjiriqi;
		
	/**
	 * 备注
	 */
	
	private String beizhu;
				
	
	/**
	 * 设置：物料支出
	 */
	 
	public void setWuliaozhichu(Float wuliaozhichu) {
		this.wuliaozhichu = wuliaozhichu;
	}
	
	/**
	 * 获取：物料支出
	 */
	public Float getWuliaozhichu() {
		return wuliaozhichu;
	}
				
	
	/**
	 * 设置：人力支出
	 */
	 
	public void setRenlizhichu(Float renlizhichu) {
		this.renlizhichu = renlizhichu;
	}
	
	/**
	 * 获取：人力支出
	 */
	public Float getRenlizhichu() {
		return renlizhichu;
	}
				
	
	/**
	 * 设置：土地租赁
	 */
	 
	public void setTudizulin(Float tudizulin) {
		this.tudizulin = tudizulin;
	}
	
	/**
	 * 获取：土地租赁
	 */
	public Float getTudizulin() {
		return tudizulin;
	}
				
	
	/**
	 * 设置：产品加工
	 */
	 
	public void setChanpinjiagong(Float chanpinjiagong) {
		this.chanpinjiagong = chanpinjiagong;
	}
	
	/**
	 * 获取：产品加工
	 */
	public Float getChanpinjiagong() {
		return chanpinjiagong;
	}
				
	
	/**
	 * 设置：其他支出
	 */
	 
	public void setQitazhichu(Float qitazhichu) {
		this.qitazhichu = qitazhichu;
	}
	
	/**
	 * 获取：其他支出
	 */
	public Float getQitazhichu() {
		return qitazhichu;
	}
				
	
	/**
	 * 设置：总支出
	 */
	 
	public void setZongzhichu(Float zongzhichu) {
		this.zongzhichu = zongzhichu;
	}
	
	/**
	 * 获取：总支出
	 */
	public Float getZongzhichu() {
		return zongzhichu;
	}
				
	
	/**
	 * 设置：登记日期
	 */
	 
	public void setDengjiriqi(Date dengjiriqi) {
		this.dengjiriqi = dengjiriqi;
	}
	
	/**
	 * 获取：登记日期
	 */
	public Date getDengjiriqi() {
		return dengjiriqi;
	}
				
	
	/**
	 * 设置：备注
	 */
	 
	public void setBeizhu(String beizhu) {
		this.beizhu = beizhu;
	}
	
	/**
	 * 获取：备注
	 */
	public String getBeizhu() {
		return beizhu;
	}
			
}
