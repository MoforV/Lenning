package com.entity.model;

import com.entity.ZhongzhiguochengEntity;

import com.baomidou.mybatisplus.annotations.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;
import java.io.Serializable;
 

/**
 * 种植过程
 * 接收传参的实体类  
 *（实际开发中配合移动端接口开发手动去掉些没用的字段， 后端一般用entity就够用了） 
 * 取自ModelAndView 的model名称
 * @author 
 * @email 
 * @date 2022-08-06 14:28:54
 */
public class ZhongzhiguochengModel  implements Serializable {
	private static final long serialVersionUID = 1L;

	 			
	/**
	 * 种植品种
	 */
	
	private String zhongzhipinzhong;
		
	/**
	 * 种植数量
	 */
	
	private Integer zhongzhishuliang;
		
	/**
	 * 种植方式
	 */
	
	private String zhongzhifangshi;
		
	/**
	 * 视频
	 */
	
	private String shipin;
		
	/**
	 * 登记日期
	 */
		
	@JsonFormat(locale="zh", timezone="GMT+8", pattern="yyyy-MM-dd HH:mm:ss")
	@DateTimeFormat 
	private Date dengjiriqi;
		
	/**
	 * 备注
	 */
	
	private String beizhu;
		
	/**
	 * 工号
	 */
	
	private String gonghao;
		
	/**
	 * 姓名
	 */
	
	private String xingming;
				
	
	/**
	 * 设置：种植品种
	 */
	 
	public void setZhongzhipinzhong(String zhongzhipinzhong) {
		this.zhongzhipinzhong = zhongzhipinzhong;
	}
	
	/**
	 * 获取：种植品种
	 */
	public String getZhongzhipinzhong() {
		return zhongzhipinzhong;
	}
				
	
	/**
	 * 设置：种植数量
	 */
	 
	public void setZhongzhishuliang(Integer zhongzhishuliang) {
		this.zhongzhishuliang = zhongzhishuliang;
	}
	
	/**
	 * 获取：种植数量
	 */
	public Integer getZhongzhishuliang() {
		return zhongzhishuliang;
	}
				
	
	/**
	 * 设置：种植方式
	 */
	 
	public void setZhongzhifangshi(String zhongzhifangshi) {
		this.zhongzhifangshi = zhongzhifangshi;
	}
	
	/**
	 * 获取：种植方式
	 */
	public String getZhongzhifangshi() {
		return zhongzhifangshi;
	}
				
	
	/**
	 * 设置：视频
	 */
	 
	public void setShipin(String shipin) {
		this.shipin = shipin;
	}
	
	/**
	 * 获取：视频
	 */
	public String getShipin() {
		return shipin;
	}
				
	
	/**
	 * 设置：登记日期
	 */
	 
	public void setDengjiriqi(Date dengjiriqi) {
		this.dengjiriqi = dengjiriqi;
	}
	
	/**
	 * 获取：登记日期
	 */
	public Date getDengjiriqi() {
		return dengjiriqi;
	}
				
	
	/**
	 * 设置：备注
	 */
	 
	public void setBeizhu(String beizhu) {
		this.beizhu = beizhu;
	}
	
	/**
	 * 获取：备注
	 */
	public String getBeizhu() {
		return beizhu;
	}
				
	
	/**
	 * 设置：工号
	 */
	 
	public void setGonghao(String gonghao) {
		this.gonghao = gonghao;
	}
	
	/**
	 * 获取：工号
	 */
	public String getGonghao() {
		return gonghao;
	}
				
	
	/**
	 * 设置：姓名
	 */
	 
	public void setXingming(String xingming) {
		this.xingming = xingming;
	}
	
	/**
	 * 获取：姓名
	 */
	public String getXingming() {
		return xingming;
	}
			
}
