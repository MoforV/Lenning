package com.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.List;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.utils.PageUtils;
import com.utils.Query;


import com.dao.ZhongzhiguochengDao;
import com.entity.ZhongzhiguochengEntity;
import com.service.ZhongzhiguochengService;
import com.entity.vo.ZhongzhiguochengVO;
import com.entity.view.ZhongzhiguochengView;

@Service("zhongzhiguochengService")
public class ZhongzhiguochengServiceImpl extends ServiceImpl<ZhongzhiguochengDao, ZhongzhiguochengEntity> implements ZhongzhiguochengService {
	

    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        Page<ZhongzhiguochengEntity> page = this.selectPage(
                new Query<ZhongzhiguochengEntity>(params).getPage(),
                new EntityWrapper<ZhongzhiguochengEntity>()
        );
        return new PageUtils(page);
    }
    
    @Override
	public PageUtils queryPage(Map<String, Object> params, Wrapper<ZhongzhiguochengEntity> wrapper) {
		  Page<ZhongzhiguochengView> page =new Query<ZhongzhiguochengView>(params).getPage();
	        page.setRecords(baseMapper.selectListView(page,wrapper));
	    	PageUtils pageUtil = new PageUtils(page);
	    	return pageUtil;
 	}
    
    @Override
	public List<ZhongzhiguochengVO> selectListVO(Wrapper<ZhongzhiguochengEntity> wrapper) {
 		return baseMapper.selectListVO(wrapper);
	}
	
	@Override
	public ZhongzhiguochengVO selectVO(Wrapper<ZhongzhiguochengEntity> wrapper) {
 		return baseMapper.selectVO(wrapper);
	}
	
	@Override
	public List<ZhongzhiguochengView> selectListView(Wrapper<ZhongzhiguochengEntity> wrapper) {
		return baseMapper.selectListView(wrapper);
	}

	@Override
	public ZhongzhiguochengView selectView(Wrapper<ZhongzhiguochengEntity> wrapper) {
		return baseMapper.selectView(wrapper);
	}


}
