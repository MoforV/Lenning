package com.entity.vo;

import com.entity.ZhongzhishujuEntity;

import com.baomidou.mybatisplus.annotations.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
 

/**
 * 种植数据
 * 手机端接口返回实体辅助类 
 * （主要作用去除一些不必要的字段）
 * @author 
 * @email 
 * @date 2022-08-06 14:28:54
 */
public class ZhongzhishujuVO  implements Serializable {
	private static final long serialVersionUID = 1L;

	 			
	/**
	 * 种植品种
	 */
	
	private String zhongzhipinzhong;
		
	/**
	 * 土壤湿度
	 */
	
	private String turangshidu;
		
	/**
	 * 土壤酸碱度
	 */
	
	private String turangsuanjiandu;
		
	/**
	 * 土壤温度
	 */
	
	private String turangwendu;
		
	/**
	 * 土壤导电率
	 */
	
	private String turangdaodianlv;
		
	/**
	 * 光照强度
	 */
	
	private String guangzhaoqiangdu;
		
	/**
	 * 登记日期
	 */
		
	@JsonFormat(locale="zh", timezone="GMT+8", pattern="yyyy-MM-dd HH:mm:ss")
	@DateTimeFormat 
	private Date dengjiriqi;
		
	/**
	 * 备注
	 */
	
	private String beizhu;
		
	/**
	 * 工号
	 */
	
	private String gonghao;
		
	/**
	 * 姓名
	 */
	
	private String xingming;
				
	
	/**
	 * 设置：种植品种
	 */
	 
	public void setZhongzhipinzhong(String zhongzhipinzhong) {
		this.zhongzhipinzhong = zhongzhipinzhong;
	}
	
	/**
	 * 获取：种植品种
	 */
	public String getZhongzhipinzhong() {
		return zhongzhipinzhong;
	}
				
	
	/**
	 * 设置：土壤湿度
	 */
	 
	public void setTurangshidu(String turangshidu) {
		this.turangshidu = turangshidu;
	}
	
	/**
	 * 获取：土壤湿度
	 */
	public String getTurangshidu() {
		return turangshidu;
	}
				
	
	/**
	 * 设置：土壤酸碱度
	 */
	 
	public void setTurangsuanjiandu(String turangsuanjiandu) {
		this.turangsuanjiandu = turangsuanjiandu;
	}
	
	/**
	 * 获取：土壤酸碱度
	 */
	public String getTurangsuanjiandu() {
		return turangsuanjiandu;
	}
				
	
	/**
	 * 设置：土壤温度
	 */
	 
	public void setTurangwendu(String turangwendu) {
		this.turangwendu = turangwendu;
	}
	
	/**
	 * 获取：土壤温度
	 */
	public String getTurangwendu() {
		return turangwendu;
	}
				
	
	/**
	 * 设置：土壤导电率
	 */
	 
	public void setTurangdaodianlv(String turangdaodianlv) {
		this.turangdaodianlv = turangdaodianlv;
	}
	
	/**
	 * 获取：土壤导电率
	 */
	public String getTurangdaodianlv() {
		return turangdaodianlv;
	}
				
	
	/**
	 * 设置：光照强度
	 */
	 
	public void setGuangzhaoqiangdu(String guangzhaoqiangdu) {
		this.guangzhaoqiangdu = guangzhaoqiangdu;
	}
	
	/**
	 * 获取：光照强度
	 */
	public String getGuangzhaoqiangdu() {
		return guangzhaoqiangdu;
	}
				
	
	/**
	 * 设置：登记日期
	 */
	 
	public void setDengjiriqi(Date dengjiriqi) {
		this.dengjiriqi = dengjiriqi;
	}
	
	/**
	 * 获取：登记日期
	 */
	public Date getDengjiriqi() {
		return dengjiriqi;
	}
				
	
	/**
	 * 设置：备注
	 */
	 
	public void setBeizhu(String beizhu) {
		this.beizhu = beizhu;
	}
	
	/**
	 * 获取：备注
	 */
	public String getBeizhu() {
		return beizhu;
	}
				
	
	/**
	 * 设置：工号
	 */
	 
	public void setGonghao(String gonghao) {
		this.gonghao = gonghao;
	}
	
	/**
	 * 获取：工号
	 */
	public String getGonghao() {
		return gonghao;
	}
				
	
	/**
	 * 设置：姓名
	 */
	 
	public void setXingming(String xingming) {
		this.xingming = xingming;
	}
	
	/**
	 * 获取：姓名
	 */
	public String getXingming() {
		return xingming;
	}
			
}
