package com.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.utils.PageUtils;
import com.entity.ZhongzhishujuEntity;
import java.util.List;
import java.util.Map;
import com.entity.vo.ZhongzhishujuVO;
import org.apache.ibatis.annotations.Param;
import com.entity.view.ZhongzhishujuView;


/**
 * 种植数据
 *
 * @author 
 * @email 
 * @date 2022-08-06 14:28:54
 */
public interface ZhongzhishujuService extends IService<ZhongzhishujuEntity> {

    PageUtils queryPage(Map<String, Object> params);
    
   	List<ZhongzhishujuVO> selectListVO(Wrapper<ZhongzhishujuEntity> wrapper);
   	
   	ZhongzhishujuVO selectVO(@Param("ew") Wrapper<ZhongzhishujuEntity> wrapper);
   	
   	List<ZhongzhishujuView> selectListView(Wrapper<ZhongzhishujuEntity> wrapper);
   	
   	ZhongzhishujuView selectView(@Param("ew") Wrapper<ZhongzhishujuEntity> wrapper);
   	
   	PageUtils queryPage(Map<String, Object> params,Wrapper<ZhongzhishujuEntity> wrapper);
   	

}

