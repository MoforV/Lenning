package com.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.utils.PageUtils;
import com.entity.ZhongzhiguochengEntity;
import java.util.List;
import java.util.Map;
import com.entity.vo.ZhongzhiguochengVO;
import org.apache.ibatis.annotations.Param;
import com.entity.view.ZhongzhiguochengView;


/**
 * 种植过程
 *
 * @author 
 * @email 
 * @date 2022-08-06 14:28:54
 */
public interface ZhongzhiguochengService extends IService<ZhongzhiguochengEntity> {

    PageUtils queryPage(Map<String, Object> params);
    
   	List<ZhongzhiguochengVO> selectListVO(Wrapper<ZhongzhiguochengEntity> wrapper);
   	
   	ZhongzhiguochengVO selectVO(@Param("ew") Wrapper<ZhongzhiguochengEntity> wrapper);
   	
   	List<ZhongzhiguochengView> selectListView(Wrapper<ZhongzhiguochengEntity> wrapper);
   	
   	ZhongzhiguochengView selectView(@Param("ew") Wrapper<ZhongzhiguochengEntity> wrapper);
   	
   	PageUtils queryPage(Map<String, Object> params,Wrapper<ZhongzhiguochengEntity> wrapper);
   	

}

