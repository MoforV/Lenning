package com.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.utils.PageUtils;
import com.entity.JidixinxiEntity;
import java.util.List;
import java.util.Map;
import com.entity.vo.JidixinxiVO;
import org.apache.ibatis.annotations.Param;
import com.entity.view.JidixinxiView;


/**
 * 基地信息
 *
 * @author 
 * @email 
 * @date 2022-08-06 14:28:53
 */
public interface JidixinxiService extends IService<JidixinxiEntity> {

    PageUtils queryPage(Map<String, Object> params);
    
   	List<JidixinxiVO> selectListVO(Wrapper<JidixinxiEntity> wrapper);
   	
   	JidixinxiVO selectVO(@Param("ew") Wrapper<JidixinxiEntity> wrapper);
   	
   	List<JidixinxiView> selectListView(Wrapper<JidixinxiEntity> wrapper);
   	
   	JidixinxiView selectView(@Param("ew") Wrapper<JidixinxiEntity> wrapper);
   	
   	PageUtils queryPage(Map<String, Object> params,Wrapper<JidixinxiEntity> wrapper);
   	

}

