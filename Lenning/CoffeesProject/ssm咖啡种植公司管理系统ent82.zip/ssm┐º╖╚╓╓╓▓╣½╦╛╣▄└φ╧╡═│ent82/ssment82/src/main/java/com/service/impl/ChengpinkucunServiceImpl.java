package com.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.List;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.utils.PageUtils;
import com.utils.Query;


import com.dao.ChengpinkucunDao;
import com.entity.ChengpinkucunEntity;
import com.service.ChengpinkucunService;
import com.entity.vo.ChengpinkucunVO;
import com.entity.view.ChengpinkucunView;

@Service("chengpinkucunService")
public class ChengpinkucunServiceImpl extends ServiceImpl<ChengpinkucunDao, ChengpinkucunEntity> implements ChengpinkucunService {
	

    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        Page<ChengpinkucunEntity> page = this.selectPage(
                new Query<ChengpinkucunEntity>(params).getPage(),
                new EntityWrapper<ChengpinkucunEntity>()
        );
        return new PageUtils(page);
    }
    
    @Override
	public PageUtils queryPage(Map<String, Object> params, Wrapper<ChengpinkucunEntity> wrapper) {
		  Page<ChengpinkucunView> page =new Query<ChengpinkucunView>(params).getPage();
	        page.setRecords(baseMapper.selectListView(page,wrapper));
	    	PageUtils pageUtil = new PageUtils(page);
	    	return pageUtil;
 	}
    
    @Override
	public List<ChengpinkucunVO> selectListVO(Wrapper<ChengpinkucunEntity> wrapper) {
 		return baseMapper.selectListVO(wrapper);
	}
	
	@Override
	public ChengpinkucunVO selectVO(Wrapper<ChengpinkucunEntity> wrapper) {
 		return baseMapper.selectVO(wrapper);
	}
	
	@Override
	public List<ChengpinkucunView> selectListView(Wrapper<ChengpinkucunEntity> wrapper) {
		return baseMapper.selectListView(wrapper);
	}

	@Override
	public ChengpinkucunView selectView(Wrapper<ChengpinkucunEntity> wrapper) {
		return baseMapper.selectView(wrapper);
	}


}
