package com.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.utils.PageUtils;
import com.entity.YuanliaokucunEntity;
import java.util.List;
import java.util.Map;
import com.entity.vo.YuanliaokucunVO;
import org.apache.ibatis.annotations.Param;
import com.entity.view.YuanliaokucunView;


/**
 * 原料库存
 *
 * @author 
 * @email 
 * @date 2022-08-06 14:28:54
 */
public interface YuanliaokucunService extends IService<YuanliaokucunEntity> {

    PageUtils queryPage(Map<String, Object> params);
    
   	List<YuanliaokucunVO> selectListVO(Wrapper<YuanliaokucunEntity> wrapper);
   	
   	YuanliaokucunVO selectVO(@Param("ew") Wrapper<YuanliaokucunEntity> wrapper);
   	
   	List<YuanliaokucunView> selectListView(Wrapper<YuanliaokucunEntity> wrapper);
   	
   	YuanliaokucunView selectView(@Param("ew") Wrapper<YuanliaokucunEntity> wrapper);
   	
   	PageUtils queryPage(Map<String, Object> params,Wrapper<YuanliaokucunEntity> wrapper);
   	

}

