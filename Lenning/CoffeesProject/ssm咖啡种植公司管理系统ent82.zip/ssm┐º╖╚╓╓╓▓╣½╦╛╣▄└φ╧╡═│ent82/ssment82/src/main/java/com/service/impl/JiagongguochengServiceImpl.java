package com.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.List;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.utils.PageUtils;
import com.utils.Query;


import com.dao.JiagongguochengDao;
import com.entity.JiagongguochengEntity;
import com.service.JiagongguochengService;
import com.entity.vo.JiagongguochengVO;
import com.entity.view.JiagongguochengView;

@Service("jiagongguochengService")
public class JiagongguochengServiceImpl extends ServiceImpl<JiagongguochengDao, JiagongguochengEntity> implements JiagongguochengService {
	

    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        Page<JiagongguochengEntity> page = this.selectPage(
                new Query<JiagongguochengEntity>(params).getPage(),
                new EntityWrapper<JiagongguochengEntity>()
        );
        return new PageUtils(page);
    }
    
    @Override
	public PageUtils queryPage(Map<String, Object> params, Wrapper<JiagongguochengEntity> wrapper) {
		  Page<JiagongguochengView> page =new Query<JiagongguochengView>(params).getPage();
	        page.setRecords(baseMapper.selectListView(page,wrapper));
	    	PageUtils pageUtil = new PageUtils(page);
	    	return pageUtil;
 	}
    
    @Override
	public List<JiagongguochengVO> selectListVO(Wrapper<JiagongguochengEntity> wrapper) {
 		return baseMapper.selectListVO(wrapper);
	}
	
	@Override
	public JiagongguochengVO selectVO(Wrapper<JiagongguochengEntity> wrapper) {
 		return baseMapper.selectVO(wrapper);
	}
	
	@Override
	public List<JiagongguochengView> selectListView(Wrapper<JiagongguochengEntity> wrapper) {
		return baseMapper.selectListView(wrapper);
	}

	@Override
	public JiagongguochengView selectView(Wrapper<JiagongguochengEntity> wrapper) {
		return baseMapper.selectView(wrapper);
	}


}
