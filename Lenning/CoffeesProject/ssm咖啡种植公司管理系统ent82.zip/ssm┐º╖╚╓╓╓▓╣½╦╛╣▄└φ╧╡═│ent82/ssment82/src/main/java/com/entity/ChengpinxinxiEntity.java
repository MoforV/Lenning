package com.entity;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.lang.reflect.InvocationTargetException;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;
import com.fasterxml.jackson.annotation.JsonFormat;
import org.apache.commons.beanutils.BeanUtils;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.enums.FieldFill;
import com.baomidou.mybatisplus.enums.IdType;


/**
 * 成品信息
 * 数据库通用操作实体类（普通增删改查）
 * @author 
 * @email 
 * @date 2022-08-06 14:28:54
 */
@TableName("chengpinxinxi")
public class ChengpinxinxiEntity<T> implements Serializable {
	private static final long serialVersionUID = 1L;


	public ChengpinxinxiEntity() {
		
	}
	
	public ChengpinxinxiEntity(T t) {
		try {
			BeanUtils.copyProperties(this, t);
		} catch (IllegalAccessException | InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * 主键id
	 */
	@TableId
	private Long id;
	/**
	 * 成品编号
	 */
					
	private String chengpinbianhao;
	
	/**
	 * 成品名称
	 */
					
	private String chengpinmingcheng;
	
	/**
	 * 成品类型
	 */
					
	private String chengpinleixing;
	
	/**
	 * 产量
	 */
					
	private Integer chanliang;
	
	/**
	 * 售价
	 */
					
	private Float shoujia;
	
	/**
	 * 登记日期
	 */
				
	@JsonFormat(locale="zh", timezone="GMT+8", pattern="yyyy-MM-dd")
	@DateTimeFormat 		
	private Date dengjiriqi;
	
	/**
	 * 成品详情
	 */
					
	private String chengpinxiangqing;
	
	/**
	 * 最近点击时间
	 */
				
	@JsonFormat(locale="zh", timezone="GMT+8", pattern="yyyy-MM-dd HH:mm:ss")
	@DateTimeFormat 		
	private Date clicktime;
	
	/**
	 * 点击次数
	 */
					
	private Integer clicknum;
	
	
	@JsonFormat(locale="zh", timezone="GMT+8", pattern="yyyy-MM-dd HH:mm:ss")
	@DateTimeFormat
	private Date addtime;

	public Date getAddtime() {
		return addtime;
	}
	public void setAddtime(Date addtime) {
		this.addtime = addtime;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	/**
	 * 设置：成品编号
	 */
	public void setChengpinbianhao(String chengpinbianhao) {
		this.chengpinbianhao = chengpinbianhao;
	}
	/**
	 * 获取：成品编号
	 */
	public String getChengpinbianhao() {
		return chengpinbianhao;
	}
	/**
	 * 设置：成品名称
	 */
	public void setChengpinmingcheng(String chengpinmingcheng) {
		this.chengpinmingcheng = chengpinmingcheng;
	}
	/**
	 * 获取：成品名称
	 */
	public String getChengpinmingcheng() {
		return chengpinmingcheng;
	}
	/**
	 * 设置：成品类型
	 */
	public void setChengpinleixing(String chengpinleixing) {
		this.chengpinleixing = chengpinleixing;
	}
	/**
	 * 获取：成品类型
	 */
	public String getChengpinleixing() {
		return chengpinleixing;
	}
	/**
	 * 设置：产量
	 */
	public void setChanliang(Integer chanliang) {
		this.chanliang = chanliang;
	}
	/**
	 * 获取：产量
	 */
	public Integer getChanliang() {
		return chanliang;
	}
	/**
	 * 设置：售价
	 */
	public void setShoujia(Float shoujia) {
		this.shoujia = shoujia;
	}
	/**
	 * 获取：售价
	 */
	public Float getShoujia() {
		return shoujia;
	}
	/**
	 * 设置：登记日期
	 */
	public void setDengjiriqi(Date dengjiriqi) {
		this.dengjiriqi = dengjiriqi;
	}
	/**
	 * 获取：登记日期
	 */
	public Date getDengjiriqi() {
		return dengjiriqi;
	}
	/**
	 * 设置：成品详情
	 */
	public void setChengpinxiangqing(String chengpinxiangqing) {
		this.chengpinxiangqing = chengpinxiangqing;
	}
	/**
	 * 获取：成品详情
	 */
	public String getChengpinxiangqing() {
		return chengpinxiangqing;
	}
	/**
	 * 设置：最近点击时间
	 */
	public void setClicktime(Date clicktime) {
		this.clicktime = clicktime;
	}
	/**
	 * 获取：最近点击时间
	 */
	public Date getClicktime() {
		return clicktime;
	}
	/**
	 * 设置：点击次数
	 */
	public void setClicknum(Integer clicknum) {
		this.clicknum = clicknum;
	}
	/**
	 * 获取：点击次数
	 */
	public Integer getClicknum() {
		return clicknum;
	}

}
