package com.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.utils.PageUtils;
import com.entity.ZhichutongjiEntity;
import java.util.List;
import java.util.Map;
import com.entity.vo.ZhichutongjiVO;
import org.apache.ibatis.annotations.Param;
import com.entity.view.ZhichutongjiView;


/**
 * 支出统计
 *
 * @author 
 * @email 
 * @date 2022-08-06 14:28:54
 */
public interface ZhichutongjiService extends IService<ZhichutongjiEntity> {

    PageUtils queryPage(Map<String, Object> params);
    
   	List<ZhichutongjiVO> selectListVO(Wrapper<ZhichutongjiEntity> wrapper);
   	
   	ZhichutongjiVO selectVO(@Param("ew") Wrapper<ZhichutongjiEntity> wrapper);
   	
   	List<ZhichutongjiView> selectListView(Wrapper<ZhichutongjiEntity> wrapper);
   	
   	ZhichutongjiView selectView(@Param("ew") Wrapper<ZhichutongjiEntity> wrapper);
   	
   	PageUtils queryPage(Map<String, Object> params,Wrapper<ZhichutongjiEntity> wrapper);
   	

    List<Map<String, Object>> selectValue(Map<String, Object> params,Wrapper<ZhichutongjiEntity> wrapper);

    List<Map<String, Object>> selectTimeStatValue(Map<String, Object> params,Wrapper<ZhichutongjiEntity> wrapper);

    List<Map<String, Object>> selectGroup(Map<String, Object> params,Wrapper<ZhichutongjiEntity> wrapper);
}

