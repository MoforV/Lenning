package com.entity.vo;

import com.entity.ShourutongjiEntity;

import com.baomidou.mybatisplus.annotations.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
 

/**
 * 收入统计
 * 手机端接口返回实体辅助类 
 * （主要作用去除一些不必要的字段）
 * @author 
 * @email 
 * @date 2022-08-06 14:28:54
 */
public class ShourutongjiVO  implements Serializable {
	private static final long serialVersionUID = 1L;

	 			
	/**
	 * 成品销额
	 */
	
	private Float chengpinxiaoe;
		
	/**
	 * 半成品额
	 */
	
	private Float banchengpine;
		
	/**
	 * 原料销额
	 */
	
	private Float yuanliaoxiaoe;
		
	/**
	 * 总收入
	 */
	
	private Float zongshouru;
		
	/**
	 * 登记日期
	 */
		
	@JsonFormat(locale="zh", timezone="GMT+8", pattern="yyyy-MM-dd HH:mm:ss")
	@DateTimeFormat 
	private Date dengjiriqi;
		
	/**
	 * 备注
	 */
	
	private String beizhu;
				
	
	/**
	 * 设置：成品销额
	 */
	 
	public void setChengpinxiaoe(Float chengpinxiaoe) {
		this.chengpinxiaoe = chengpinxiaoe;
	}
	
	/**
	 * 获取：成品销额
	 */
	public Float getChengpinxiaoe() {
		return chengpinxiaoe;
	}
				
	
	/**
	 * 设置：半成品额
	 */
	 
	public void setBanchengpine(Float banchengpine) {
		this.banchengpine = banchengpine;
	}
	
	/**
	 * 获取：半成品额
	 */
	public Float getBanchengpine() {
		return banchengpine;
	}
				
	
	/**
	 * 设置：原料销额
	 */
	 
	public void setYuanliaoxiaoe(Float yuanliaoxiaoe) {
		this.yuanliaoxiaoe = yuanliaoxiaoe;
	}
	
	/**
	 * 获取：原料销额
	 */
	public Float getYuanliaoxiaoe() {
		return yuanliaoxiaoe;
	}
				
	
	/**
	 * 设置：总收入
	 */
	 
	public void setZongshouru(Float zongshouru) {
		this.zongshouru = zongshouru;
	}
	
	/**
	 * 获取：总收入
	 */
	public Float getZongshouru() {
		return zongshouru;
	}
				
	
	/**
	 * 设置：登记日期
	 */
	 
	public void setDengjiriqi(Date dengjiriqi) {
		this.dengjiriqi = dengjiriqi;
	}
	
	/**
	 * 获取：登记日期
	 */
	public Date getDengjiriqi() {
		return dengjiriqi;
	}
				
	
	/**
	 * 设置：备注
	 */
	 
	public void setBeizhu(String beizhu) {
		this.beizhu = beizhu;
	}
	
	/**
	 * 获取：备注
	 */
	public String getBeizhu() {
		return beizhu;
	}
			
}
