package com.entity.model;

import com.entity.YuanliaoxinxiEntity;

import com.baomidou.mybatisplus.annotations.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;
import java.io.Serializable;
 

/**
 * 原料信息
 * 接收传参的实体类  
 *（实际开发中配合移动端接口开发手动去掉些没用的字段， 后端一般用entity就够用了） 
 * 取自ModelAndView 的model名称
 * @author 
 * @email 
 * @date 2022-08-06 14:28:54
 */
public class YuanliaoxinxiModel  implements Serializable {
	private static final long serialVersionUID = 1L;

	 			
	/**
	 * 咖啡豆品种
	 */
	
	private String kafeidoupinzhong;
		
	/**
	 * 产量
	 */
	
	private Integer chanliang;
		
	/**
	 * 位置
	 */
	
	private String weizhi;
		
	/**
	 * 登记日期
	 */
		
	@JsonFormat(locale="zh", timezone="GMT+8", pattern="yyyy-MM-dd HH:mm:ss")
	@DateTimeFormat 
	private Date dengjiriqi;
		
	/**
	 * 原料详情
	 */
	
	private String yuanliaoxiangqing;
				
	
	/**
	 * 设置：咖啡豆品种
	 */
	 
	public void setKafeidoupinzhong(String kafeidoupinzhong) {
		this.kafeidoupinzhong = kafeidoupinzhong;
	}
	
	/**
	 * 获取：咖啡豆品种
	 */
	public String getKafeidoupinzhong() {
		return kafeidoupinzhong;
	}
				
	
	/**
	 * 设置：产量
	 */
	 
	public void setChanliang(Integer chanliang) {
		this.chanliang = chanliang;
	}
	
	/**
	 * 获取：产量
	 */
	public Integer getChanliang() {
		return chanliang;
	}
				
	
	/**
	 * 设置：位置
	 */
	 
	public void setWeizhi(String weizhi) {
		this.weizhi = weizhi;
	}
	
	/**
	 * 获取：位置
	 */
	public String getWeizhi() {
		return weizhi;
	}
				
	
	/**
	 * 设置：登记日期
	 */
	 
	public void setDengjiriqi(Date dengjiriqi) {
		this.dengjiriqi = dengjiriqi;
	}
	
	/**
	 * 获取：登记日期
	 */
	public Date getDengjiriqi() {
		return dengjiriqi;
	}
				
	
	/**
	 * 设置：原料详情
	 */
	 
	public void setYuanliaoxiangqing(String yuanliaoxiangqing) {
		this.yuanliaoxiangqing = yuanliaoxiangqing;
	}
	
	/**
	 * 获取：原料详情
	 */
	public String getYuanliaoxiangqing() {
		return yuanliaoxiangqing;
	}
			
}
