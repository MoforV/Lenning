package com.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.List;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.utils.PageUtils;
import com.utils.Query;


import com.dao.JidixinxiDao;
import com.entity.JidixinxiEntity;
import com.service.JidixinxiService;
import com.entity.vo.JidixinxiVO;
import com.entity.view.JidixinxiView;

@Service("jidixinxiService")
public class JidixinxiServiceImpl extends ServiceImpl<JidixinxiDao, JidixinxiEntity> implements JidixinxiService {
	

    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        Page<JidixinxiEntity> page = this.selectPage(
                new Query<JidixinxiEntity>(params).getPage(),
                new EntityWrapper<JidixinxiEntity>()
        );
        return new PageUtils(page);
    }
    
    @Override
	public PageUtils queryPage(Map<String, Object> params, Wrapper<JidixinxiEntity> wrapper) {
		  Page<JidixinxiView> page =new Query<JidixinxiView>(params).getPage();
	        page.setRecords(baseMapper.selectListView(page,wrapper));
	    	PageUtils pageUtil = new PageUtils(page);
	    	return pageUtil;
 	}
    
    @Override
	public List<JidixinxiVO> selectListVO(Wrapper<JidixinxiEntity> wrapper) {
 		return baseMapper.selectListVO(wrapper);
	}
	
	@Override
	public JidixinxiVO selectVO(Wrapper<JidixinxiEntity> wrapper) {
 		return baseMapper.selectVO(wrapper);
	}
	
	@Override
	public List<JidixinxiView> selectListView(Wrapper<JidixinxiEntity> wrapper) {
		return baseMapper.selectListView(wrapper);
	}

	@Override
	public JidixinxiView selectView(Wrapper<JidixinxiEntity> wrapper) {
		return baseMapper.selectView(wrapper);
	}


}
