package com.entity;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.lang.reflect.InvocationTargetException;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;
import com.fasterxml.jackson.annotation.JsonFormat;
import org.apache.commons.beanutils.BeanUtils;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.enums.FieldFill;
import com.baomidou.mybatisplus.enums.IdType;


/**
 * 原料信息
 * 数据库通用操作实体类（普通增删改查）
 * @author 
 * @email 
 * @date 2022-08-06 14:28:54
 */
@TableName("yuanliaoxinxi")
public class YuanliaoxinxiEntity<T> implements Serializable {
	private static final long serialVersionUID = 1L;


	public YuanliaoxinxiEntity() {
		
	}
	
	public YuanliaoxinxiEntity(T t) {
		try {
			BeanUtils.copyProperties(this, t);
		} catch (IllegalAccessException | InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * 主键id
	 */
	@TableId
	private Long id;
	/**
	 * 原料编号
	 */
					
	private String yuanliaobianhao;
	
	/**
	 * 咖啡豆品种
	 */
					
	private String kafeidoupinzhong;
	
	/**
	 * 产量
	 */
					
	private Integer chanliang;
	
	/**
	 * 位置
	 */
					
	private String weizhi;
	
	/**
	 * 登记日期
	 */
				
	@JsonFormat(locale="zh", timezone="GMT+8", pattern="yyyy-MM-dd")
	@DateTimeFormat 		
	private Date dengjiriqi;
	
	/**
	 * 原料详情
	 */
					
	private String yuanliaoxiangqing;
	
	
	@JsonFormat(locale="zh", timezone="GMT+8", pattern="yyyy-MM-dd HH:mm:ss")
	@DateTimeFormat
	private Date addtime;

	public Date getAddtime() {
		return addtime;
	}
	public void setAddtime(Date addtime) {
		this.addtime = addtime;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	/**
	 * 设置：原料编号
	 */
	public void setYuanliaobianhao(String yuanliaobianhao) {
		this.yuanliaobianhao = yuanliaobianhao;
	}
	/**
	 * 获取：原料编号
	 */
	public String getYuanliaobianhao() {
		return yuanliaobianhao;
	}
	/**
	 * 设置：咖啡豆品种
	 */
	public void setKafeidoupinzhong(String kafeidoupinzhong) {
		this.kafeidoupinzhong = kafeidoupinzhong;
	}
	/**
	 * 获取：咖啡豆品种
	 */
	public String getKafeidoupinzhong() {
		return kafeidoupinzhong;
	}
	/**
	 * 设置：产量
	 */
	public void setChanliang(Integer chanliang) {
		this.chanliang = chanliang;
	}
	/**
	 * 获取：产量
	 */
	public Integer getChanliang() {
		return chanliang;
	}
	/**
	 * 设置：位置
	 */
	public void setWeizhi(String weizhi) {
		this.weizhi = weizhi;
	}
	/**
	 * 获取：位置
	 */
	public String getWeizhi() {
		return weizhi;
	}
	/**
	 * 设置：登记日期
	 */
	public void setDengjiriqi(Date dengjiriqi) {
		this.dengjiriqi = dengjiriqi;
	}
	/**
	 * 获取：登记日期
	 */
	public Date getDengjiriqi() {
		return dengjiriqi;
	}
	/**
	 * 设置：原料详情
	 */
	public void setYuanliaoxiangqing(String yuanliaoxiangqing) {
		this.yuanliaoxiangqing = yuanliaoxiangqing;
	}
	/**
	 * 获取：原料详情
	 */
	public String getYuanliaoxiangqing() {
		return yuanliaoxiangqing;
	}

}
