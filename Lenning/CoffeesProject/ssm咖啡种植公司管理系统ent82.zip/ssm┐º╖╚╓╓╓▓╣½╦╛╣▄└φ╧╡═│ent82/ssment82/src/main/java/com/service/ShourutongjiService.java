package com.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.utils.PageUtils;
import com.entity.ShourutongjiEntity;
import java.util.List;
import java.util.Map;
import com.entity.vo.ShourutongjiVO;
import org.apache.ibatis.annotations.Param;
import com.entity.view.ShourutongjiView;


/**
 * 收入统计
 *
 * @author 
 * @email 
 * @date 2022-08-06 14:28:54
 */
public interface ShourutongjiService extends IService<ShourutongjiEntity> {

    PageUtils queryPage(Map<String, Object> params);
    
   	List<ShourutongjiVO> selectListVO(Wrapper<ShourutongjiEntity> wrapper);
   	
   	ShourutongjiVO selectVO(@Param("ew") Wrapper<ShourutongjiEntity> wrapper);
   	
   	List<ShourutongjiView> selectListView(Wrapper<ShourutongjiEntity> wrapper);
   	
   	ShourutongjiView selectView(@Param("ew") Wrapper<ShourutongjiEntity> wrapper);
   	
   	PageUtils queryPage(Map<String, Object> params,Wrapper<ShourutongjiEntity> wrapper);
   	

    List<Map<String, Object>> selectValue(Map<String, Object> params,Wrapper<ShourutongjiEntity> wrapper);

    List<Map<String, Object>> selectTimeStatValue(Map<String, Object> params,Wrapper<ShourutongjiEntity> wrapper);

    List<Map<String, Object>> selectGroup(Map<String, Object> params,Wrapper<ShourutongjiEntity> wrapper);
}

