package com.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.List;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.utils.PageUtils;
import com.utils.Query;


import com.dao.FeiliaokucunDao;
import com.entity.FeiliaokucunEntity;
import com.service.FeiliaokucunService;
import com.entity.vo.FeiliaokucunVO;
import com.entity.view.FeiliaokucunView;

@Service("feiliaokucunService")
public class FeiliaokucunServiceImpl extends ServiceImpl<FeiliaokucunDao, FeiliaokucunEntity> implements FeiliaokucunService {
	

    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        Page<FeiliaokucunEntity> page = this.selectPage(
                new Query<FeiliaokucunEntity>(params).getPage(),
                new EntityWrapper<FeiliaokucunEntity>()
        );
        return new PageUtils(page);
    }
    
    @Override
	public PageUtils queryPage(Map<String, Object> params, Wrapper<FeiliaokucunEntity> wrapper) {
		  Page<FeiliaokucunView> page =new Query<FeiliaokucunView>(params).getPage();
	        page.setRecords(baseMapper.selectListView(page,wrapper));
	    	PageUtils pageUtil = new PageUtils(page);
	    	return pageUtil;
 	}
    
    @Override
	public List<FeiliaokucunVO> selectListVO(Wrapper<FeiliaokucunEntity> wrapper) {
 		return baseMapper.selectListVO(wrapper);
	}
	
	@Override
	public FeiliaokucunVO selectVO(Wrapper<FeiliaokucunEntity> wrapper) {
 		return baseMapper.selectVO(wrapper);
	}
	
	@Override
	public List<FeiliaokucunView> selectListView(Wrapper<FeiliaokucunEntity> wrapper) {
		return baseMapper.selectListView(wrapper);
	}

	@Override
	public FeiliaokucunView selectView(Wrapper<FeiliaokucunEntity> wrapper) {
		return baseMapper.selectView(wrapper);
	}


}
