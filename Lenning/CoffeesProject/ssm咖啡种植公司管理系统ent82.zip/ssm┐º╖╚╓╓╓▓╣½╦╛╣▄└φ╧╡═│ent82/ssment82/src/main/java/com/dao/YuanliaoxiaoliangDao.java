package com.dao;

import com.entity.YuanliaoxiaoliangEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.entity.vo.YuanliaoxiaoliangVO;
import com.entity.view.YuanliaoxiaoliangView;


/**
 * 原料销量
 * 
 * @author 
 * @email 
 * @date 2022-08-06 14:28:54
 */
public interface YuanliaoxiaoliangDao extends BaseMapper<YuanliaoxiaoliangEntity> {
	
	List<YuanliaoxiaoliangVO> selectListVO(@Param("ew") Wrapper<YuanliaoxiaoliangEntity> wrapper);
	
	YuanliaoxiaoliangVO selectVO(@Param("ew") Wrapper<YuanliaoxiaoliangEntity> wrapper);
	
	List<YuanliaoxiaoliangView> selectListView(@Param("ew") Wrapper<YuanliaoxiaoliangEntity> wrapper);

	List<YuanliaoxiaoliangView> selectListView(Pagination page,@Param("ew") Wrapper<YuanliaoxiaoliangEntity> wrapper);
	
	YuanliaoxiaoliangView selectView(@Param("ew") Wrapper<YuanliaoxiaoliangEntity> wrapper);
	

}
