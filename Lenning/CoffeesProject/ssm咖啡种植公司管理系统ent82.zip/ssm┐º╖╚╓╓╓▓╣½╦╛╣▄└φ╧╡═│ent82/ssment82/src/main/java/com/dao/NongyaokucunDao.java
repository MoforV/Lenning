package com.dao;

import com.entity.NongyaokucunEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.entity.vo.NongyaokucunVO;
import com.entity.view.NongyaokucunView;


/**
 * 农药库存
 * 
 * @author 
 * @email 
 * @date 2022-08-06 14:28:54
 */
public interface NongyaokucunDao extends BaseMapper<NongyaokucunEntity> {
	
	List<NongyaokucunVO> selectListVO(@Param("ew") Wrapper<NongyaokucunEntity> wrapper);
	
	NongyaokucunVO selectVO(@Param("ew") Wrapper<NongyaokucunEntity> wrapper);
	
	List<NongyaokucunView> selectListView(@Param("ew") Wrapper<NongyaokucunEntity> wrapper);

	List<NongyaokucunView> selectListView(Pagination page,@Param("ew") Wrapper<NongyaokucunEntity> wrapper);
	
	NongyaokucunView selectView(@Param("ew") Wrapper<NongyaokucunEntity> wrapper);
	

}
