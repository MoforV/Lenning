package com.dao;

import com.entity.ZhongzhishujuEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.entity.vo.ZhongzhishujuVO;
import com.entity.view.ZhongzhishujuView;


/**
 * 种植数据
 * 
 * @author 
 * @email 
 * @date 2022-08-06 14:28:54
 */
public interface ZhongzhishujuDao extends BaseMapper<ZhongzhishujuEntity> {
	
	List<ZhongzhishujuVO> selectListVO(@Param("ew") Wrapper<ZhongzhishujuEntity> wrapper);
	
	ZhongzhishujuVO selectVO(@Param("ew") Wrapper<ZhongzhishujuEntity> wrapper);
	
	List<ZhongzhishujuView> selectListView(@Param("ew") Wrapper<ZhongzhishujuEntity> wrapper);

	List<ZhongzhishujuView> selectListView(Pagination page,@Param("ew") Wrapper<ZhongzhishujuEntity> wrapper);
	
	ZhongzhishujuView selectView(@Param("ew") Wrapper<ZhongzhishujuEntity> wrapper);
	

}
