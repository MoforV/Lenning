package com.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.List;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.utils.PageUtils;
import com.utils.Query;


import com.dao.ZhichutongjiDao;
import com.entity.ZhichutongjiEntity;
import com.service.ZhichutongjiService;
import com.entity.vo.ZhichutongjiVO;
import com.entity.view.ZhichutongjiView;

@Service("zhichutongjiService")
public class ZhichutongjiServiceImpl extends ServiceImpl<ZhichutongjiDao, ZhichutongjiEntity> implements ZhichutongjiService {
	

    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        Page<ZhichutongjiEntity> page = this.selectPage(
                new Query<ZhichutongjiEntity>(params).getPage(),
                new EntityWrapper<ZhichutongjiEntity>()
        );
        return new PageUtils(page);
    }
    
    @Override
	public PageUtils queryPage(Map<String, Object> params, Wrapper<ZhichutongjiEntity> wrapper) {
		  Page<ZhichutongjiView> page =new Query<ZhichutongjiView>(params).getPage();
	        page.setRecords(baseMapper.selectListView(page,wrapper));
	    	PageUtils pageUtil = new PageUtils(page);
	    	return pageUtil;
 	}
    
    @Override
	public List<ZhichutongjiVO> selectListVO(Wrapper<ZhichutongjiEntity> wrapper) {
 		return baseMapper.selectListVO(wrapper);
	}
	
	@Override
	public ZhichutongjiVO selectVO(Wrapper<ZhichutongjiEntity> wrapper) {
 		return baseMapper.selectVO(wrapper);
	}
	
	@Override
	public List<ZhichutongjiView> selectListView(Wrapper<ZhichutongjiEntity> wrapper) {
		return baseMapper.selectListView(wrapper);
	}

	@Override
	public ZhichutongjiView selectView(Wrapper<ZhichutongjiEntity> wrapper) {
		return baseMapper.selectView(wrapper);
	}

    @Override
    public List<Map<String, Object>> selectValue(Map<String, Object> params, Wrapper<ZhichutongjiEntity> wrapper) {
        return baseMapper.selectValue(params, wrapper);
    }

    @Override
    public List<Map<String, Object>> selectTimeStatValue(Map<String, Object> params, Wrapper<ZhichutongjiEntity> wrapper) {
        return baseMapper.selectTimeStatValue(params, wrapper);
    }

    @Override
    public List<Map<String, Object>> selectGroup(Map<String, Object> params, Wrapper<ZhichutongjiEntity> wrapper) {
        return baseMapper.selectGroup(params, wrapper);
    }

}
