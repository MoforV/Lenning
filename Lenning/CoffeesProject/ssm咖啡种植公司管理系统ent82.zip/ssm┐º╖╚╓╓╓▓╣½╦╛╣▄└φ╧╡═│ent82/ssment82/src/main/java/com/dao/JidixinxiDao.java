package com.dao;

import com.entity.JidixinxiEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.entity.vo.JidixinxiVO;
import com.entity.view.JidixinxiView;


/**
 * 基地信息
 * 
 * @author 
 * @email 
 * @date 2022-08-06 14:28:53
 */
public interface JidixinxiDao extends BaseMapper<JidixinxiEntity> {
	
	List<JidixinxiVO> selectListVO(@Param("ew") Wrapper<JidixinxiEntity> wrapper);
	
	JidixinxiVO selectVO(@Param("ew") Wrapper<JidixinxiEntity> wrapper);
	
	List<JidixinxiView> selectListView(@Param("ew") Wrapper<JidixinxiEntity> wrapper);

	List<JidixinxiView> selectListView(Pagination page,@Param("ew") Wrapper<JidixinxiEntity> wrapper);
	
	JidixinxiView selectView(@Param("ew") Wrapper<JidixinxiEntity> wrapper);
	

}
