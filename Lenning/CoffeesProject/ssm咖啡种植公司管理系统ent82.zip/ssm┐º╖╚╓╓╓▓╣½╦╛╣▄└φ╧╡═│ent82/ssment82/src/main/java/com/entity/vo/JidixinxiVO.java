package com.entity.vo;

import com.entity.JidixinxiEntity;

import com.baomidou.mybatisplus.annotations.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
 

/**
 * 基地信息
 * 手机端接口返回实体辅助类 
 * （主要作用去除一些不必要的字段）
 * @author 
 * @email 
 * @date 2022-08-06 14:28:53
 */
public class JidixinxiVO  implements Serializable {
	private static final long serialVersionUID = 1L;

	 			
	/**
	 * 基地名称
	 */
	
	private String jidimingcheng;
		
	/**
	 * 基地照片
	 */
	
	private String jidizhaopian;
		
	/**
	 * 基地地址
	 */
	
	private String jididizhi;
		
	/**
	 * 种植品种
	 */
	
	private String zhongzhipinzhong;
		
	/**
	 * 基地面积
	 */
	
	private String jidimianji;
		
	/**
	 * 土壤情况
	 */
	
	private String turangqingkuang;
		
	/**
	 * 种植数量
	 */
	
	private Integer zhongzhishuliang;
		
	/**
	 * 基地简介
	 */
	
	private String jidijianjie;
		
	/**
	 * 赞
	 */
	
	private Integer thumbsupnum;
		
	/**
	 * 踩
	 */
	
	private Integer crazilynum;
				
	
	/**
	 * 设置：基地名称
	 */
	 
	public void setJidimingcheng(String jidimingcheng) {
		this.jidimingcheng = jidimingcheng;
	}
	
	/**
	 * 获取：基地名称
	 */
	public String getJidimingcheng() {
		return jidimingcheng;
	}
				
	
	/**
	 * 设置：基地照片
	 */
	 
	public void setJidizhaopian(String jidizhaopian) {
		this.jidizhaopian = jidizhaopian;
	}
	
	/**
	 * 获取：基地照片
	 */
	public String getJidizhaopian() {
		return jidizhaopian;
	}
				
	
	/**
	 * 设置：基地地址
	 */
	 
	public void setJididizhi(String jididizhi) {
		this.jididizhi = jididizhi;
	}
	
	/**
	 * 获取：基地地址
	 */
	public String getJididizhi() {
		return jididizhi;
	}
				
	
	/**
	 * 设置：种植品种
	 */
	 
	public void setZhongzhipinzhong(String zhongzhipinzhong) {
		this.zhongzhipinzhong = zhongzhipinzhong;
	}
	
	/**
	 * 获取：种植品种
	 */
	public String getZhongzhipinzhong() {
		return zhongzhipinzhong;
	}
				
	
	/**
	 * 设置：基地面积
	 */
	 
	public void setJidimianji(String jidimianji) {
		this.jidimianji = jidimianji;
	}
	
	/**
	 * 获取：基地面积
	 */
	public String getJidimianji() {
		return jidimianji;
	}
				
	
	/**
	 * 设置：土壤情况
	 */
	 
	public void setTurangqingkuang(String turangqingkuang) {
		this.turangqingkuang = turangqingkuang;
	}
	
	/**
	 * 获取：土壤情况
	 */
	public String getTurangqingkuang() {
		return turangqingkuang;
	}
				
	
	/**
	 * 设置：种植数量
	 */
	 
	public void setZhongzhishuliang(Integer zhongzhishuliang) {
		this.zhongzhishuliang = zhongzhishuliang;
	}
	
	/**
	 * 获取：种植数量
	 */
	public Integer getZhongzhishuliang() {
		return zhongzhishuliang;
	}
				
	
	/**
	 * 设置：基地简介
	 */
	 
	public void setJidijianjie(String jidijianjie) {
		this.jidijianjie = jidijianjie;
	}
	
	/**
	 * 获取：基地简介
	 */
	public String getJidijianjie() {
		return jidijianjie;
	}
				
	
	/**
	 * 设置：赞
	 */
	 
	public void setThumbsupnum(Integer thumbsupnum) {
		this.thumbsupnum = thumbsupnum;
	}
	
	/**
	 * 获取：赞
	 */
	public Integer getThumbsupnum() {
		return thumbsupnum;
	}
				
	
	/**
	 * 设置：踩
	 */
	 
	public void setCrazilynum(Integer crazilynum) {
		this.crazilynum = crazilynum;
	}
	
	/**
	 * 获取：踩
	 */
	public Integer getCrazilynum() {
		return crazilynum;
	}
			
}
