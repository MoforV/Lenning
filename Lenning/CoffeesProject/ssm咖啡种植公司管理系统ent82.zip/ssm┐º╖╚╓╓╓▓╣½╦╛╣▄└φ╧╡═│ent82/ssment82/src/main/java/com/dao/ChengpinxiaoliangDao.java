package com.dao;

import com.entity.ChengpinxiaoliangEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.entity.vo.ChengpinxiaoliangVO;
import com.entity.view.ChengpinxiaoliangView;


/**
 * 成品销量
 * 
 * @author 
 * @email 
 * @date 2022-08-06 14:28:54
 */
public interface ChengpinxiaoliangDao extends BaseMapper<ChengpinxiaoliangEntity> {
	
	List<ChengpinxiaoliangVO> selectListVO(@Param("ew") Wrapper<ChengpinxiaoliangEntity> wrapper);
	
	ChengpinxiaoliangVO selectVO(@Param("ew") Wrapper<ChengpinxiaoliangEntity> wrapper);
	
	List<ChengpinxiaoliangView> selectListView(@Param("ew") Wrapper<ChengpinxiaoliangEntity> wrapper);

	List<ChengpinxiaoliangView> selectListView(Pagination page,@Param("ew") Wrapper<ChengpinxiaoliangEntity> wrapper);
	
	ChengpinxiaoliangView selectView(@Param("ew") Wrapper<ChengpinxiaoliangEntity> wrapper);
	

}
