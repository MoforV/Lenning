package com.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.utils.PageUtils;
import com.entity.WuliaocaigouEntity;
import java.util.List;
import java.util.Map;
import com.entity.vo.WuliaocaigouVO;
import org.apache.ibatis.annotations.Param;
import com.entity.view.WuliaocaigouView;


/**
 * 物料采购
 *
 * @author 
 * @email 
 * @date 2022-08-06 14:28:54
 */
public interface WuliaocaigouService extends IService<WuliaocaigouEntity> {

    PageUtils queryPage(Map<String, Object> params);
    
   	List<WuliaocaigouVO> selectListVO(Wrapper<WuliaocaigouEntity> wrapper);
   	
   	WuliaocaigouVO selectVO(@Param("ew") Wrapper<WuliaocaigouEntity> wrapper);
   	
   	List<WuliaocaigouView> selectListView(Wrapper<WuliaocaigouEntity> wrapper);
   	
   	WuliaocaigouView selectView(@Param("ew") Wrapper<WuliaocaigouEntity> wrapper);
   	
   	PageUtils queryPage(Map<String, Object> params,Wrapper<WuliaocaigouEntity> wrapper);
   	

}

