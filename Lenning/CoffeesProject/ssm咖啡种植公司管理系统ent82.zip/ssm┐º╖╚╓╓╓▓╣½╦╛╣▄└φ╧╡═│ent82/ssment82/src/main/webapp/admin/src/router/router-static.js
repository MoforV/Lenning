import Vue from 'vue';
//配置路由
import VueRouter from 'vue-router'
Vue.use(VueRouter);
//1.创建组件
import Index from '@/views/index'
import Home from '@/views/home'
import Login from '@/views/login'
import NotFound from '@/views/404'
import UpdatePassword from '@/views/update-password'
import pay from '@/views/pay'
import register from '@/views/register'
import center from '@/views/center'
    import zhongzhifangan from '@/views/modules/zhongzhifangan/list'
    import yuangong from '@/views/modules/yuangong/list'
    import feiliaokucun from '@/views/modules/feiliaokucun/list'
    import nongyaokucun from '@/views/modules/nongyaokucun/list'
    import shourutongji from '@/views/modules/shourutongji/list'
    import zhongzhiguocheng from '@/views/modules/zhongzhiguocheng/list'
    import chengpinxinxi from '@/views/modules/chengpinxinxi/list'
    import jiagongguocheng from '@/views/modules/jiagongguocheng/list'
    import yuanliaoxiaoliang from '@/views/modules/yuanliaoxiaoliang/list'
    import kehuxinxi from '@/views/modules/kehuxinxi/list'
    import zhongzhishuju from '@/views/modules/zhongzhishuju/list'
    import menu from '@/views/modules/menu/list'
    import yuanliaokucun from '@/views/modules/yuanliaokucun/list'
    import wuliaocaigou from '@/views/modules/wuliaocaigou/list'
    import bumenxinxi from '@/views/modules/bumenxinxi/list'
    import jidixinxi from '@/views/modules/jidixinxi/list'
    import banchengpinxiaoliang from '@/views/modules/banchengpinxiaoliang/list'
    import zhichutongji from '@/views/modules/zhichutongji/list'
    import chengpinxiaoliang from '@/views/modules/chengpinxiaoliang/list'
    import yuanliaoxinxi from '@/views/modules/yuanliaoxinxi/list'
    import xinxitongji from '@/views/modules/xinxitongji/list'
    import chengpinkucun from '@/views/modules/chengpinkucun/list'


//2.配置路由   注意：名字
const routes = [{
    path: '/index',
    name: '首页',
    component: Index,
    children: [{
      // 这里不设置值，是把main作为默认页面
      path: '/',
      name: '首页',
      component: Home,
      meta: {icon:'', title:'center'}
    }, {
      path: '/updatePassword',
      name: '修改密码',
      component: UpdatePassword,
      meta: {icon:'', title:'updatePassword'}
    }, {
      path: '/pay',
      name: '支付',
      component: pay,
      meta: {icon:'', title:'pay'}
    }, {
      path: '/center',
      name: '个人信息',
      component: center,
      meta: {icon:'', title:'center'}
    }
      ,{
	path: '/zhongzhifangan',
        name: '种植方案',
        component: zhongzhifangan
      }
      ,{
	path: '/yuangong',
        name: '员工',
        component: yuangong
      }
      ,{
	path: '/feiliaokucun',
        name: '肥料库存',
        component: feiliaokucun
      }
      ,{
	path: '/nongyaokucun',
        name: '农药库存',
        component: nongyaokucun
      }
      ,{
	path: '/shourutongji',
        name: '收入统计',
        component: shourutongji
      }
      ,{
	path: '/zhongzhiguocheng',
        name: '种植过程',
        component: zhongzhiguocheng
      }
      ,{
	path: '/chengpinxinxi',
        name: '成品信息',
        component: chengpinxinxi
      }
      ,{
	path: '/jiagongguocheng',
        name: '加工过程',
        component: jiagongguocheng
      }
      ,{
	path: '/yuanliaoxiaoliang',
        name: '原料销量',
        component: yuanliaoxiaoliang
      }
      ,{
	path: '/kehuxinxi',
        name: '客户信息',
        component: kehuxinxi
      }
      ,{
	path: '/zhongzhishuju',
        name: '种植数据',
        component: zhongzhishuju
      }
      ,{
	path: '/menu',
        name: '菜单列表',
        component: menu
      }
      ,{
	path: '/yuanliaokucun',
        name: '原料库存',
        component: yuanliaokucun
      }
      ,{
	path: '/wuliaocaigou',
        name: '物料采购',
        component: wuliaocaigou
      }
      ,{
	path: '/bumenxinxi',
        name: '部门信息',
        component: bumenxinxi
      }
      ,{
	path: '/jidixinxi',
        name: '基地信息',
        component: jidixinxi
      }
      ,{
	path: '/banchengpinxiaoliang',
        name: '半成品销量',
        component: banchengpinxiaoliang
      }
      ,{
	path: '/zhichutongji',
        name: '支出统计',
        component: zhichutongji
      }
      ,{
	path: '/chengpinxiaoliang',
        name: '成品销量',
        component: chengpinxiaoliang
      }
      ,{
	path: '/yuanliaoxinxi',
        name: '原料信息',
        component: yuanliaoxinxi
      }
      ,{
	path: '/xinxitongji',
        name: '信息统计',
        component: xinxitongji
      }
      ,{
	path: '/chengpinkucun',
        name: '成品库存',
        component: chengpinkucun
      }
    ]
  },
  {
    path: '/login',
    name: 'login',
    component: Login,
    meta: {icon:'', title:'login'}
  },
  {
    path: '/register',
    name: 'register',
    component: register,
    meta: {icon:'', title:'register'}
  },
  {
    path: '/',
    name: '首页',
    redirect: '/index'
  }, /*默认跳转路由*/
  {
    path: '*',
    component: NotFound
  }
]
//3.实例化VueRouter  注意：名字
const router = new VueRouter({
  mode: 'hash',
  /*hash模式改为history*/
  routes // （缩写）相当于 routes: routes
})

export default router;
