const base = {
    get() {
        return {
            url : "http://localhost:8080/ssment82/",
            name: "ssment82",
            // 退出到首页链接
            indexUrl: ''
        };
    },
    getProjectName(){
        return {
            projectName: "咖啡种植公司管理系统"
        } 
    }
}
export default base
