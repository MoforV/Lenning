-- MySQL dump 10.13  Distrib 5.7.31, for Linux (x86_64)
--
-- Host: localhost    Database: ssment82
-- ------------------------------------------------------
-- Server version	5.7.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `ssment82`
--

/*!40000 DROP DATABASE IF EXISTS `ssment82`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `ssment82` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;

USE `ssment82`;

--
-- Table structure for table `banchengpinxiaoliang`
--

DROP TABLE IF EXISTS `banchengpinxiaoliang`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `banchengpinxiaoliang` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `tongjibianhao` varchar(200) DEFAULT NULL COMMENT '统计编号',
  `chengpinmingcheng` varchar(200) NOT NULL COMMENT '成品名称',
  `chengpinxiaoliang` int(11) DEFAULT NULL COMMENT '成品销量',
  `dengjiriqi` date DEFAULT NULL COMMENT '登记日期',
  `beizhu` varchar(200) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`),
  UNIQUE KEY `tongjibianhao` (`tongjibianhao`)
) ENGINE=InnoDB AUTO_INCREMENT=147 DEFAULT CHARSET=utf8 COMMENT='半成品销量';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `banchengpinxiaoliang`
--

LOCK TABLES `banchengpinxiaoliang` WRITE;
/*!40000 ALTER TABLE `banchengpinxiaoliang` DISABLE KEYS */;
INSERT INTO `banchengpinxiaoliang` VALUES (141,'2022-08-06 06:29:15','1111111111','成品名称1',1,'2022-08-06','备注1'),(142,'2022-08-06 06:29:15','2222222222','成品名称2',2,'2022-08-06','备注2'),(143,'2022-08-06 06:29:15','3333333333','成品名称3',3,'2022-08-06','备注3'),(144,'2022-08-06 06:29:15','4444444444','成品名称4',4,'2022-08-06','备注4'),(145,'2022-08-06 06:29:15','5555555555','成品名称5',5,'2022-08-06','备注5'),(146,'2022-08-06 06:29:15','6666666666','成品名称6',6,'2022-08-06','备注6');
/*!40000 ALTER TABLE `banchengpinxiaoliang` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bumenxinxi`
--

DROP TABLE IF EXISTS `bumenxinxi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bumenxinxi` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `bumenbianhao` varchar(200) DEFAULT NULL COMMENT '部门编号',
  `bumenmingcheng` varchar(200) DEFAULT NULL COMMENT '部门名称',
  `bumenrenshu` int(11) DEFAULT NULL COMMENT '部门人数',
  `bumendianhua` varchar(200) DEFAULT NULL COMMENT '部门电话',
  `bumenjieshao` longtext COMMENT '部门介绍',
  PRIMARY KEY (`id`),
  UNIQUE KEY `bumenbianhao` (`bumenbianhao`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8 COMMENT='部门信息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bumenxinxi`
--

LOCK TABLES `bumenxinxi` WRITE;
/*!40000 ALTER TABLE `bumenxinxi` DISABLE KEYS */;
INSERT INTO `bumenxinxi` VALUES (21,'2022-08-06 06:29:15','1111111111','部门名称1',1,'部门电话1','部门介绍1'),(22,'2022-08-06 06:29:15','2222222222','部门名称2',2,'部门电话2','部门介绍2'),(23,'2022-08-06 06:29:15','3333333333','部门名称3',3,'部门电话3','部门介绍3'),(24,'2022-08-06 06:29:15','4444444444','部门名称4',4,'部门电话4','部门介绍4'),(25,'2022-08-06 06:29:15','5555555555','部门名称5',5,'部门电话5','部门介绍5'),(26,'2022-08-06 06:29:15','6666666666','部门名称6',6,'部门电话6','部门介绍6');
/*!40000 ALTER TABLE `bumenxinxi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chengpinkucun`
--

DROP TABLE IF EXISTS `chengpinkucun`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chengpinkucun` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `chengpinbianhao` varchar(200) DEFAULT NULL COMMENT '成品编号',
  `chengpinmingcheng` varchar(200) NOT NULL COMMENT '成品名称',
  `chengpinleibie` varchar(200) NOT NULL COMMENT '成品类别',
  `shuliang` int(11) DEFAULT NULL COMMENT '数量',
  `chengpinxiangqing` longtext COMMENT '成品详情',
  `dengjiriqi` date DEFAULT NULL COMMENT '登记日期',
  `clicktime` datetime DEFAULT NULL COMMENT '最近点击时间',
  `clicknum` int(11) DEFAULT '0' COMMENT '点击次数',
  PRIMARY KEY (`id`),
  UNIQUE KEY `chengpinbianhao` (`chengpinbianhao`)
) ENGINE=InnoDB AUTO_INCREMENT=217 DEFAULT CHARSET=utf8 COMMENT='成品库存';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chengpinkucun`
--

LOCK TABLES `chengpinkucun` WRITE;
/*!40000 ALTER TABLE `chengpinkucun` DISABLE KEYS */;
INSERT INTO `chengpinkucun` VALUES (211,'2022-08-06 06:29:15','1111111111','成品名称1','成品类别1',1,'成品详情1','2022-08-06','2022-08-06 14:29:15',1),(212,'2022-08-06 06:29:15','2222222222','成品名称2','成品类别2',2,'成品详情2','2022-08-06','2022-08-06 14:29:15',2),(213,'2022-08-06 06:29:15','3333333333','成品名称3','成品类别3',3,'成品详情3','2022-08-06','2022-08-06 14:29:15',3),(214,'2022-08-06 06:29:15','4444444444','成品名称4','成品类别4',4,'成品详情4','2022-08-06','2022-08-06 14:29:15',4),(215,'2022-08-06 06:29:15','5555555555','成品名称5','成品类别5',5,'成品详情5','2022-08-06','2022-08-06 14:29:15',5),(216,'2022-08-06 06:29:15','6666666666','成品名称6','成品类别6',6,'成品详情6','2022-08-06','2022-08-06 14:29:15',6);
/*!40000 ALTER TABLE `chengpinkucun` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chengpinxiaoliang`
--

DROP TABLE IF EXISTS `chengpinxiaoliang`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chengpinxiaoliang` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `tongjibianhao` varchar(200) DEFAULT NULL COMMENT '统计编号',
  `chengpinmingcheng` varchar(200) NOT NULL COMMENT '成品名称',
  `chengpinxiaoliang` int(11) DEFAULT NULL COMMENT '成品销量',
  `dengjiriqi` date DEFAULT NULL COMMENT '登记日期',
  `beizhu` varchar(200) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`),
  UNIQUE KEY `tongjibianhao` (`tongjibianhao`)
) ENGINE=InnoDB AUTO_INCREMENT=137 DEFAULT CHARSET=utf8 COMMENT='成品销量';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chengpinxiaoliang`
--

LOCK TABLES `chengpinxiaoliang` WRITE;
/*!40000 ALTER TABLE `chengpinxiaoliang` DISABLE KEYS */;
INSERT INTO `chengpinxiaoliang` VALUES (131,'2022-08-06 06:29:15','1111111111','成品名称1',1,'2022-08-06','备注1'),(132,'2022-08-06 06:29:15','2222222222','成品名称2',2,'2022-08-06','备注2'),(133,'2022-08-06 06:29:15','3333333333','成品名称3',3,'2022-08-06','备注3'),(134,'2022-08-06 06:29:15','4444444444','成品名称4',4,'2022-08-06','备注4'),(135,'2022-08-06 06:29:15','5555555555','成品名称5',5,'2022-08-06','备注5'),(136,'2022-08-06 06:29:15','6666666666','成品名称6',6,'2022-08-06','备注6');
/*!40000 ALTER TABLE `chengpinxiaoliang` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chengpinxinxi`
--

DROP TABLE IF EXISTS `chengpinxinxi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chengpinxinxi` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `chengpinbianhao` varchar(200) DEFAULT NULL COMMENT '成品编号',
  `chengpinmingcheng` varchar(200) NOT NULL COMMENT '成品名称',
  `chengpinleixing` varchar(200) DEFAULT NULL COMMENT '成品类型',
  `chanliang` int(11) DEFAULT NULL COMMENT '产量',
  `shoujia` float DEFAULT NULL COMMENT '售价',
  `dengjiriqi` date DEFAULT NULL COMMENT '登记日期',
  `chengpinxiangqing` longtext COMMENT '成品详情',
  `clicktime` datetime DEFAULT NULL COMMENT '最近点击时间',
  `clicknum` int(11) DEFAULT '0' COMMENT '点击次数',
  PRIMARY KEY (`id`),
  UNIQUE KEY `chengpinbianhao` (`chengpinbianhao`)
) ENGINE=InnoDB AUTO_INCREMENT=117 DEFAULT CHARSET=utf8 COMMENT='成品信息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chengpinxinxi`
--

LOCK TABLES `chengpinxinxi` WRITE;
/*!40000 ALTER TABLE `chengpinxinxi` DISABLE KEYS */;
INSERT INTO `chengpinxinxi` VALUES (111,'2022-08-06 06:29:15','1111111111','成品名称1','半成品',1,1,'2022-08-06','成品详情1','2022-08-06 14:29:15',1),(112,'2022-08-06 06:29:15','2222222222','成品名称2','半成品',2,2,'2022-08-06','成品详情2','2022-08-06 14:29:15',2),(113,'2022-08-06 06:29:15','3333333333','成品名称3','半成品',3,3,'2022-08-06','成品详情3','2022-08-06 14:29:15',3),(114,'2022-08-06 06:29:15','4444444444','成品名称4','半成品',4,4,'2022-08-06','成品详情4','2022-08-06 14:29:15',4),(115,'2022-08-06 06:29:15','5555555555','成品名称5','半成品',5,5,'2022-08-06','成品详情5','2022-08-06 14:29:15',5),(116,'2022-08-06 06:29:15','6666666666','成品名称6','半成品',6,6,'2022-08-06','成品详情6','2022-08-06 14:29:15',6);
/*!40000 ALTER TABLE `chengpinxinxi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config`
--

DROP TABLE IF EXISTS `config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `config` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(100) NOT NULL COMMENT '配置参数名称',
  `value` varchar(100) DEFAULT NULL COMMENT '配置参数值',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='配置文件';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config`
--

LOCK TABLES `config` WRITE;
/*!40000 ALTER TABLE `config` DISABLE KEYS */;
INSERT INTO `config` VALUES (1,'picture1','upload/picture1.jpg'),(2,'picture2','upload/picture2.jpg'),(3,'picture3','upload/picture3.jpg');
/*!40000 ALTER TABLE `config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feiliaokucun`
--

DROP TABLE IF EXISTS `feiliaokucun`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feiliaokucun` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `feiliaobianhao` varchar(200) DEFAULT NULL COMMENT '肥料编号',
  `feiliaomingcheng` varchar(200) NOT NULL COMMENT '肥料名称',
  `feiliaoleibie` varchar(200) NOT NULL COMMENT '肥料类别',
  `shuliang` int(11) DEFAULT NULL COMMENT '数量',
  `feiliaoxiangqing` longtext COMMENT '肥料详情',
  `dengjiriqi` date DEFAULT NULL COMMENT '登记日期',
  `clicktime` datetime DEFAULT NULL COMMENT '最近点击时间',
  `clicknum` int(11) DEFAULT '0' COMMENT '点击次数',
  PRIMARY KEY (`id`),
  UNIQUE KEY `feiliaobianhao` (`feiliaobianhao`)
) ENGINE=InnoDB AUTO_INCREMENT=187 DEFAULT CHARSET=utf8 COMMENT='肥料库存';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feiliaokucun`
--

LOCK TABLES `feiliaokucun` WRITE;
/*!40000 ALTER TABLE `feiliaokucun` DISABLE KEYS */;
INSERT INTO `feiliaokucun` VALUES (181,'2022-08-06 06:29:15','1111111111','肥料名称1','肥料类别1',1,'肥料详情1','2022-08-06','2022-08-06 14:29:15',1),(182,'2022-08-06 06:29:15','2222222222','肥料名称2','肥料类别2',2,'肥料详情2','2022-08-06','2022-08-06 14:29:15',2),(183,'2022-08-06 06:29:15','3333333333','肥料名称3','肥料类别3',3,'肥料详情3','2022-08-06','2022-08-06 14:29:15',3),(184,'2022-08-06 06:29:15','4444444444','肥料名称4','肥料类别4',4,'肥料详情4','2022-08-06','2022-08-06 14:29:15',4),(185,'2022-08-06 06:29:15','5555555555','肥料名称5','肥料类别5',5,'肥料详情5','2022-08-06','2022-08-06 14:29:15',5),(186,'2022-08-06 06:29:15','6666666666','肥料名称6','肥料类别6',6,'肥料详情6','2022-08-06','2022-08-06 14:29:15',6);
/*!40000 ALTER TABLE `feiliaokucun` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jiagongguocheng`
--

DROP TABLE IF EXISTS `jiagongguocheng`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jiagongguocheng` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `dengjibianhao` varchar(200) DEFAULT NULL COMMENT '登记编号',
  `jiagongleixing` varchar(200) DEFAULT NULL COMMENT '加工类型',
  `guocheng` varchar(200) DEFAULT NULL COMMENT '过程',
  `dengjiriqi` date DEFAULT NULL COMMENT '登记日期',
  `gonghao` varchar(200) DEFAULT NULL COMMENT '工号',
  `xingming` varchar(200) DEFAULT NULL COMMENT '姓名',
  PRIMARY KEY (`id`),
  UNIQUE KEY `dengjibianhao` (`dengjibianhao`)
) ENGINE=InnoDB AUTO_INCREMENT=107 DEFAULT CHARSET=utf8 COMMENT='加工过程';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jiagongguocheng`
--

LOCK TABLES `jiagongguocheng` WRITE;
/*!40000 ALTER TABLE `jiagongguocheng` DISABLE KEYS */;
INSERT INTO `jiagongguocheng` VALUES (101,'2022-08-06 06:29:15','1111111111','半加工','','2022-08-06','工号1','姓名1'),(102,'2022-08-06 06:29:15','2222222222','半加工','','2022-08-06','工号2','姓名2'),(103,'2022-08-06 06:29:15','3333333333','半加工','','2022-08-06','工号3','姓名3'),(104,'2022-08-06 06:29:15','4444444444','半加工','','2022-08-06','工号4','姓名4'),(105,'2022-08-06 06:29:15','5555555555','半加工','','2022-08-06','工号5','姓名5'),(106,'2022-08-06 06:29:15','6666666666','半加工','','2022-08-06','工号6','姓名6');
/*!40000 ALTER TABLE `jiagongguocheng` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jidixinxi`
--

DROP TABLE IF EXISTS `jidixinxi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jidixinxi` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `jidibianhao` varchar(200) NOT NULL COMMENT '基地编号',
  `jidimingcheng` varchar(200) NOT NULL COMMENT '基地名称',
  `jidizhaopian` varchar(200) DEFAULT NULL COMMENT '基地照片',
  `jididizhi` varchar(200) DEFAULT NULL COMMENT '基地地址',
  `zhongzhipinzhong` longtext COMMENT '种植品种',
  `jidimianji` varchar(200) DEFAULT NULL COMMENT '基地面积',
  `turangqingkuang` varchar(200) DEFAULT NULL COMMENT '土壤情况',
  `zhongzhishuliang` int(11) DEFAULT NULL COMMENT '种植数量',
  `jidijianjie` longtext COMMENT '基地简介',
  `thumbsupnum` int(11) DEFAULT '0' COMMENT '赞',
  `crazilynum` int(11) DEFAULT '0' COMMENT '踩',
  PRIMARY KEY (`id`),
  UNIQUE KEY `jidibianhao` (`jidibianhao`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8 COMMENT='基地信息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jidixinxi`
--

LOCK TABLES `jidixinxi` WRITE;
/*!40000 ALTER TABLE `jidixinxi` DISABLE KEYS */;
INSERT INTO `jidixinxi` VALUES (31,'2022-08-06 06:29:15','1111111111','基地名称1','upload/jidixinxi_jidizhaopian1.jpg','基地地址1','种植品种1','基地面积1','土壤情况1',1,'基地简介1',1,1),(32,'2022-08-06 06:29:15','2222222222','基地名称2','upload/jidixinxi_jidizhaopian2.jpg','基地地址2','种植品种2','基地面积2','土壤情况2',2,'基地简介2',2,2),(33,'2022-08-06 06:29:15','3333333333','基地名称3','upload/jidixinxi_jidizhaopian3.jpg','基地地址3','种植品种3','基地面积3','土壤情况3',3,'基地简介3',3,3),(34,'2022-08-06 06:29:15','4444444444','基地名称4','upload/jidixinxi_jidizhaopian4.jpg','基地地址4','种植品种4','基地面积4','土壤情况4',4,'基地简介4',4,4),(35,'2022-08-06 06:29:15','5555555555','基地名称5','upload/jidixinxi_jidizhaopian5.jpg','基地地址5','种植品种5','基地面积5','土壤情况5',5,'基地简介5',5,5),(36,'2022-08-06 06:29:15','6666666666','基地名称6','upload/jidixinxi_jidizhaopian6.jpg','基地地址6','种植品种6','基地面积6','土壤情况6',6,'基地简介6',6,6);
/*!40000 ALTER TABLE `jidixinxi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kehuxinxi`
--

DROP TABLE IF EXISTS `kehuxinxi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kehuxinxi` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `kehubianhao` varchar(200) DEFAULT NULL COMMENT '客户编号',
  `kehuxingming` varchar(200) NOT NULL COMMENT '客户姓名',
  `xingbie` varchar(200) DEFAULT NULL COMMENT '性别',
  `shenfenzheng` varchar(200) DEFAULT NULL COMMENT '身份证',
  `lianxidianhua` varchar(200) DEFAULT NULL COMMENT '联系电话',
  `goumaipinzhong` varchar(200) DEFAULT NULL COMMENT '购买品种',
  `goumailiang` int(11) DEFAULT NULL COMMENT '购买量',
  `beizhu` longtext COMMENT '备注',
  PRIMARY KEY (`id`),
  UNIQUE KEY `kehubianhao` (`kehubianhao`)
) ENGINE=InnoDB AUTO_INCREMENT=127 DEFAULT CHARSET=utf8 COMMENT='客户信息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kehuxinxi`
--

LOCK TABLES `kehuxinxi` WRITE;
/*!40000 ALTER TABLE `kehuxinxi` DISABLE KEYS */;
INSERT INTO `kehuxinxi` VALUES (121,'2022-08-06 06:29:15','1111111111','客户姓名1','男','440300199101010001','13823888881','购买品种1',1,'备注1'),(122,'2022-08-06 06:29:15','2222222222','客户姓名2','男','440300199202020002','13823888882','购买品种2',2,'备注2'),(123,'2022-08-06 06:29:15','3333333333','客户姓名3','男','440300199303030003','13823888883','购买品种3',3,'备注3'),(124,'2022-08-06 06:29:15','4444444444','客户姓名4','男','440300199404040004','13823888884','购买品种4',4,'备注4'),(125,'2022-08-06 06:29:15','5555555555','客户姓名5','男','440300199505050005','13823888885','购买品种5',5,'备注5'),(126,'2022-08-06 06:29:15','6666666666','客户姓名6','男','440300199606060006','13823888886','购买品种6',6,'备注6');
/*!40000 ALTER TABLE `kehuxinxi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu`
--

DROP TABLE IF EXISTS `menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `menujson` longtext COMMENT '菜单',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='菜单';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu`
--

LOCK TABLES `menu` WRITE;
/*!40000 ALTER TABLE `menu` DISABLE KEYS */;
INSERT INTO `menu` VALUES (1,'2022-08-06 06:29:15','[{\"backMenu\":[{\"child\":[{\"appFrontIcon\":\"cuIcon-similar\",\"buttons\":[\"新增\",\"查看\",\"修改\",\"删除\"],\"menu\":\"员工\",\"menuJump\":\"列表\",\"tableName\":\"yuangong\"}],\"menu\":\"员工管理\"},{\"child\":[{\"appFrontIcon\":\"cuIcon-discover\",\"buttons\":[\"新增\",\"查看\",\"修改\",\"删除\"],\"menu\":\"部门信息\",\"menuJump\":\"列表\",\"tableName\":\"bumenxinxi\"}],\"menu\":\"部门信息管理\"},{\"child\":[{\"appFrontIcon\":\"cuIcon-news\",\"buttons\":[\"新增\",\"查看\",\"修改\",\"删除\"],\"menu\":\"基地信息\",\"menuJump\":\"列表\",\"tableName\":\"jidixinxi\"}],\"menu\":\"基地信息管理\"},{\"child\":[{\"appFrontIcon\":\"cuIcon-list\",\"buttons\":[\"查看\",\"修改\",\"删除\"],\"menu\":\"物料采购\",\"menuJump\":\"列表\",\"tableName\":\"wuliaocaigou\"}],\"menu\":\"物料采购管理\"},{\"child\":[{\"appFrontIcon\":\"cuIcon-skin\",\"buttons\":[\"查看\",\"修改\",\"删除\"],\"menu\":\"种植过程\",\"menuJump\":\"列表\",\"tableName\":\"zhongzhiguocheng\"}],\"menu\":\"种植过程管理\"},{\"child\":[{\"appFrontIcon\":\"cuIcon-phone\",\"buttons\":[\"查看\",\"修改\",\"删除\"],\"menu\":\"种植数据\",\"menuJump\":\"列表\",\"tableName\":\"zhongzhishuju\"}],\"menu\":\"种植数据管理\"},{\"child\":[{\"appFrontIcon\":\"cuIcon-medal\",\"buttons\":[\"新增\",\"查看\",\"修改\",\"删除\"],\"menu\":\"种植方案\",\"menuJump\":\"列表\",\"tableName\":\"zhongzhifangan\"}],\"menu\":\"种植方案管理\"},{\"child\":[{\"appFrontIcon\":\"cuIcon-send\",\"buttons\":[\"新增\",\"查看\",\"修改\",\"删除\"],\"menu\":\"信息统计\",\"menuJump\":\"列表\",\"tableName\":\"xinxitongji\"}],\"menu\":\"信息统计管理\"},{\"child\":[{\"appFrontIcon\":\"cuIcon-rank\",\"buttons\":[\"新增\",\"查看\",\"修改\",\"删除\"],\"menu\":\"原料信息\",\"menuJump\":\"列表\",\"tableName\":\"yuanliaoxinxi\"}],\"menu\":\"原料信息管理\"},{\"child\":[{\"appFrontIcon\":\"cuIcon-copy\",\"buttons\":[\"新增\",\"查看\",\"修改\",\"删除\"],\"menu\":\"加工过程\",\"menuJump\":\"列表\",\"tableName\":\"jiagongguocheng\"}],\"menu\":\"加工过程管理\"},{\"child\":[{\"appFrontIcon\":\"cuIcon-link\",\"buttons\":[\"新增\",\"查看\",\"修改\",\"删除\"],\"menu\":\"成品信息\",\"menuJump\":\"列表\",\"tableName\":\"chengpinxinxi\"}],\"menu\":\"成品信息管理\"},{\"child\":[{\"appFrontIcon\":\"cuIcon-pic\",\"buttons\":[\"新增\",\"查看\",\"修改\",\"删除\"],\"menu\":\"客户信息\",\"menuJump\":\"列表\",\"tableName\":\"kehuxinxi\"}],\"menu\":\"客户信息管理\"},{\"child\":[{\"appFrontIcon\":\"cuIcon-vip\",\"buttons\":[\"新增\",\"查看\",\"修改\",\"删除\"],\"menu\":\"成品销量\",\"menuJump\":\"列表\",\"tableName\":\"chengpinxiaoliang\"}],\"menu\":\"成品销量管理\"},{\"child\":[{\"appFrontIcon\":\"cuIcon-goods\",\"buttons\":[\"新增\",\"查看\",\"修改\",\"删除\"],\"menu\":\"半成品销量\",\"menuJump\":\"列表\",\"tableName\":\"banchengpinxiaoliang\"}],\"menu\":\"半成品销量管理\"},{\"child\":[{\"appFrontIcon\":\"cuIcon-skin\",\"buttons\":[\"新增\",\"查看\",\"修改\",\"删除\"],\"menu\":\"原料销量\",\"menuJump\":\"列表\",\"tableName\":\"yuanliaoxiaoliang\"}],\"menu\":\"原料销量管理\"},{\"child\":[{\"appFrontIcon\":\"cuIcon-rank\",\"buttons\":[\"新增\",\"查看\",\"修改\",\"删除\",\"报表\"],\"menu\":\"收入统计\",\"menuJump\":\"列表\",\"tableName\":\"shourutongji\"}],\"menu\":\"收入统计管理\"},{\"child\":[{\"appFrontIcon\":\"cuIcon-vipcard\",\"buttons\":[\"新增\",\"查看\",\"修改\",\"删除\",\"报表\"],\"menu\":\"支出统计\",\"menuJump\":\"列表\",\"tableName\":\"zhichutongji\"}],\"menu\":\"支出统计管理\"},{\"child\":[{\"appFrontIcon\":\"cuIcon-form\",\"buttons\":[\"新增\",\"查看\",\"修改\",\"删除\"],\"menu\":\"肥料库存\",\"menuJump\":\"列表\",\"tableName\":\"feiliaokucun\"}],\"menu\":\"肥料库存管理\"},{\"child\":[{\"appFrontIcon\":\"cuIcon-medal\",\"buttons\":[\"新增\",\"查看\",\"修改\",\"删除\"],\"menu\":\"农药库存\",\"menuJump\":\"列表\",\"tableName\":\"nongyaokucun\"}],\"menu\":\"农药库存管理\"},{\"child\":[{\"appFrontIcon\":\"cuIcon-skin\",\"buttons\":[\"新增\",\"查看\",\"修改\",\"删除\"],\"menu\":\"原料库存\",\"menuJump\":\"列表\",\"tableName\":\"yuanliaokucun\"}],\"menu\":\"原料库存管理\"},{\"child\":[{\"appFrontIcon\":\"cuIcon-medal\",\"buttons\":[\"新增\",\"查看\",\"修改\",\"删除\"],\"menu\":\"成品库存\",\"menuJump\":\"列表\",\"tableName\":\"chengpinkucun\"}],\"menu\":\"成品库存管理\"},{\"child\":[{\"appFrontIcon\":\"cuIcon-cardboard\",\"buttons\":[\"查看\",\"编辑名称\",\"编辑父级\",\"删除\"],\"menu\":\"菜单列表\",\"tableName\":\"menu\"}],\"menu\":\"系统管理\"}],\"frontMenu\":[],\"hasBackLogin\":\"是\",\"hasBackRegister\":\"否\",\"hasFrontLogin\":\"否\",\"hasFrontRegister\":\"否\",\"roleName\":\"管理员\",\"tableName\":\"users\"},{\"backMenu\":[{\"child\":[{\"appFrontIcon\":\"cuIcon-list\",\"buttons\":[\"新增\",\"查看\",\"修改\",\"删除\"],\"menu\":\"物料采购\",\"menuJump\":\"列表\",\"tableName\":\"wuliaocaigou\"}],\"menu\":\"物料采购管理\"},{\"child\":[{\"appFrontIcon\":\"cuIcon-skin\",\"buttons\":[\"新增\",\"查看\",\"修改\",\"删除\"],\"menu\":\"种植过程\",\"menuJump\":\"列表\",\"tableName\":\"zhongzhiguocheng\"}],\"menu\":\"种植过程管理\"},{\"child\":[{\"appFrontIcon\":\"cuIcon-phone\",\"buttons\":[\"新增\",\"查看\",\"修改\",\"删除\"],\"menu\":\"种植数据\",\"menuJump\":\"列表\",\"tableName\":\"zhongzhishuju\"}],\"menu\":\"种植数据管理\"},{\"child\":[{\"appFrontIcon\":\"cuIcon-medal\",\"buttons\":[\"查看\"],\"menu\":\"种植方案\",\"menuJump\":\"列表\",\"tableName\":\"zhongzhifangan\"}],\"menu\":\"种植方案管理\"},{\"child\":[{\"appFrontIcon\":\"cuIcon-copy\",\"buttons\":[\"新增\",\"查看\",\"修改\",\"删除\"],\"menu\":\"加工过程\",\"menuJump\":\"列表\",\"tableName\":\"jiagongguocheng\"}],\"menu\":\"加工过程管理\"},{\"child\":[{\"appFrontIcon\":\"cuIcon-vip\",\"buttons\":[\"查看\"],\"menu\":\"成品销量\",\"menuJump\":\"列表\",\"tableName\":\"chengpinxiaoliang\"}],\"menu\":\"成品销量管理\"},{\"child\":[{\"appFrontIcon\":\"cuIcon-goods\",\"buttons\":[\"查看\"],\"menu\":\"半成品销量\",\"menuJump\":\"列表\",\"tableName\":\"banchengpinxiaoliang\"}],\"menu\":\"半成品销量管理\"},{\"child\":[{\"appFrontIcon\":\"cuIcon-skin\",\"buttons\":[\"查看\"],\"menu\":\"原料销量\",\"menuJump\":\"列表\",\"tableName\":\"yuanliaoxiaoliang\"}],\"menu\":\"原料销量管理\"},{\"child\":[{\"appFrontIcon\":\"cuIcon-form\",\"buttons\":[\"查看\"],\"menu\":\"肥料库存\",\"menuJump\":\"列表\",\"tableName\":\"feiliaokucun\"}],\"menu\":\"肥料库存管理\"},{\"child\":[{\"appFrontIcon\":\"cuIcon-medal\",\"buttons\":[\"查看\"],\"menu\":\"农药库存\",\"menuJump\":\"列表\",\"tableName\":\"nongyaokucun\"}],\"menu\":\"农药库存管理\"},{\"child\":[{\"appFrontIcon\":\"cuIcon-skin\",\"buttons\":[\"查看\"],\"menu\":\"原料库存\",\"menuJump\":\"列表\",\"tableName\":\"yuanliaokucun\"}],\"menu\":\"原料库存管理\"},{\"child\":[{\"appFrontIcon\":\"cuIcon-medal\",\"buttons\":[\"查看\"],\"menu\":\"成品库存\",\"menuJump\":\"列表\",\"tableName\":\"chengpinkucun\"}],\"menu\":\"成品库存管理\"}],\"frontMenu\":[],\"hasBackLogin\":\"是\",\"hasBackRegister\":\"是\",\"hasFrontLogin\":\"否\",\"hasFrontRegister\":\"否\",\"roleName\":\"员工\",\"tableName\":\"yuangong\"}]');
/*!40000 ALTER TABLE `menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nongyaokucun`
--

DROP TABLE IF EXISTS `nongyaokucun`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nongyaokucun` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `nongyaobianhao` varchar(200) DEFAULT NULL COMMENT '农药编号',
  `nongyaomingcheng` varchar(200) NOT NULL COMMENT '农药名称',
  `nongyaoleibie` varchar(200) NOT NULL COMMENT '农药类别',
  `shuliang` int(11) DEFAULT NULL COMMENT '数量',
  `nongyaoxiangqing` longtext COMMENT '农药详情',
  `dengjiriqi` date DEFAULT NULL COMMENT '登记日期',
  `clicktime` datetime DEFAULT NULL COMMENT '最近点击时间',
  `clicknum` int(11) DEFAULT '0' COMMENT '点击次数',
  PRIMARY KEY (`id`),
  UNIQUE KEY `nongyaobianhao` (`nongyaobianhao`)
) ENGINE=InnoDB AUTO_INCREMENT=197 DEFAULT CHARSET=utf8 COMMENT='农药库存';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nongyaokucun`
--

LOCK TABLES `nongyaokucun` WRITE;
/*!40000 ALTER TABLE `nongyaokucun` DISABLE KEYS */;
INSERT INTO `nongyaokucun` VALUES (191,'2022-08-06 06:29:15','1111111111','农药名称1','农药类别1',1,'农药详情1','2022-08-06','2022-08-06 14:29:15',1),(192,'2022-08-06 06:29:15','2222222222','农药名称2','农药类别2',2,'农药详情2','2022-08-06','2022-08-06 14:29:15',2),(193,'2022-08-06 06:29:15','3333333333','农药名称3','农药类别3',3,'农药详情3','2022-08-06','2022-08-06 14:29:15',3),(194,'2022-08-06 06:29:15','4444444444','农药名称4','农药类别4',4,'农药详情4','2022-08-06','2022-08-06 14:29:15',4),(195,'2022-08-06 06:29:15','5555555555','农药名称5','农药类别5',5,'农药详情5','2022-08-06','2022-08-06 14:29:15',5),(196,'2022-08-06 06:29:15','6666666666','农药名称6','农药类别6',6,'农药详情6','2022-08-06','2022-08-06 14:29:15',6);
/*!40000 ALTER TABLE `nongyaokucun` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shourutongji`
--

DROP TABLE IF EXISTS `shourutongji`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shourutongji` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `tongjibianhao` varchar(200) DEFAULT NULL COMMENT '统计编号',
  `chengpinxiaoe` float DEFAULT NULL COMMENT '成品销额',
  `banchengpine` float DEFAULT NULL COMMENT '半成品额',
  `yuanliaoxiaoe` float DEFAULT NULL COMMENT '原料销额',
  `zongshouru` float DEFAULT NULL COMMENT '总收入',
  `dengjiriqi` date DEFAULT NULL COMMENT '登记日期',
  `beizhu` varchar(200) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`),
  UNIQUE KEY `tongjibianhao` (`tongjibianhao`)
) ENGINE=InnoDB AUTO_INCREMENT=167 DEFAULT CHARSET=utf8 COMMENT='收入统计';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shourutongji`
--

LOCK TABLES `shourutongji` WRITE;
/*!40000 ALTER TABLE `shourutongji` DISABLE KEYS */;
INSERT INTO `shourutongji` VALUES (161,'2022-08-06 06:29:15','1111111111',1,1,1,1,'2022-08-06','备注1'),(162,'2022-08-06 06:29:15','2222222222',2,2,2,2,'2022-08-06','备注2'),(163,'2022-08-06 06:29:15','3333333333',3,3,3,3,'2022-08-06','备注3'),(164,'2022-08-06 06:29:15','4444444444',4,4,4,4,'2022-08-06','备注4'),(165,'2022-08-06 06:29:15','5555555555',5,5,5,5,'2022-08-06','备注5'),(166,'2022-08-06 06:29:15','6666666666',6,6,6,6,'2022-08-06','备注6');
/*!40000 ALTER TABLE `shourutongji` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `storeup`
--

DROP TABLE IF EXISTS `storeup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `storeup` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `userid` bigint(20) NOT NULL COMMENT '用户id',
  `refid` bigint(20) DEFAULT NULL COMMENT '收藏id',
  `tablename` varchar(200) DEFAULT NULL COMMENT '表名',
  `name` varchar(200) NOT NULL COMMENT '收藏名称',
  `picture` varchar(200) NOT NULL COMMENT '收藏图片',
  `type` varchar(200) DEFAULT '1' COMMENT '类型(1:收藏,21:赞,22:踩)',
  `inteltype` varchar(200) DEFAULT NULL COMMENT '推荐类型',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='收藏表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `storeup`
--

LOCK TABLES `storeup` WRITE;
/*!40000 ALTER TABLE `storeup` DISABLE KEYS */;
/*!40000 ALTER TABLE `storeup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `token`
--

DROP TABLE IF EXISTS `token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `token` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `userid` bigint(20) NOT NULL COMMENT '用户id',
  `username` varchar(100) NOT NULL COMMENT '用户名',
  `tablename` varchar(100) DEFAULT NULL COMMENT '表名',
  `role` varchar(100) DEFAULT NULL COMMENT '角色',
  `token` varchar(200) NOT NULL COMMENT '密码',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '新增时间',
  `expiratedtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '过期时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='token表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `token`
--

LOCK TABLES `token` WRITE;
/*!40000 ALTER TABLE `token` DISABLE KEYS */;
/*!40000 ALTER TABLE `token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `username` varchar(100) NOT NULL COMMENT '用户名',
  `password` varchar(100) NOT NULL COMMENT '密码',
  `role` varchar(100) DEFAULT '管理员' COMMENT '角色',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '新增时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='用户表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'abo','abo','管理员','2022-08-06 06:29:15');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wuliaocaigou`
--

DROP TABLE IF EXISTS `wuliaocaigou`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wuliaocaigou` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `wuliaobianhao` varchar(200) DEFAULT NULL COMMENT '物料编号',
  `wuliaomingcheng` varchar(200) NOT NULL COMMENT '物料名称',
  `wuliaoleixing` varchar(200) NOT NULL COMMENT '物料类型',
  `shuliang` int(11) DEFAULT NULL COMMENT '数量',
  `wuliaoxiangqing` longtext COMMENT '物料详情',
  `gonghao` varchar(200) DEFAULT NULL COMMENT '工号',
  `xingming` varchar(200) DEFAULT NULL COMMENT '姓名',
  `clicktime` datetime DEFAULT NULL COMMENT '最近点击时间',
  `clicknum` int(11) DEFAULT '0' COMMENT '点击次数',
  PRIMARY KEY (`id`),
  UNIQUE KEY `wuliaobianhao` (`wuliaobianhao`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8 COMMENT='物料采购';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wuliaocaigou`
--

LOCK TABLES `wuliaocaigou` WRITE;
/*!40000 ALTER TABLE `wuliaocaigou` DISABLE KEYS */;
INSERT INTO `wuliaocaigou` VALUES (41,'2022-08-06 06:29:15','1111111111','物料名称1','物料类型1',1,'物料详情1','工号1','姓名1','2022-08-06 14:29:15',1),(42,'2022-08-06 06:29:15','2222222222','物料名称2','物料类型2',2,'物料详情2','工号2','姓名2','2022-08-06 14:29:15',2),(43,'2022-08-06 06:29:15','3333333333','物料名称3','物料类型3',3,'物料详情3','工号3','姓名3','2022-08-06 14:29:15',3),(44,'2022-08-06 06:29:15','4444444444','物料名称4','物料类型4',4,'物料详情4','工号4','姓名4','2022-08-06 14:29:15',4),(45,'2022-08-06 06:29:15','5555555555','物料名称5','物料类型5',5,'物料详情5','工号5','姓名5','2022-08-06 14:29:15',5),(46,'2022-08-06 06:29:15','6666666666','物料名称6','物料类型6',6,'物料详情6','工号6','姓名6','2022-08-06 14:29:15',6);
/*!40000 ALTER TABLE `wuliaocaigou` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xinxitongji`
--

DROP TABLE IF EXISTS `xinxitongji`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `xinxitongji` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `tongjibianhao` varchar(200) DEFAULT NULL COMMENT '统计编号',
  `jidimingcheng` varchar(200) NOT NULL COMMENT '基地名称',
  `jidimianji` varchar(200) DEFAULT NULL COMMENT '基地面积',
  `zhongzhishuliang` int(11) DEFAULT NULL COMMENT '种植数量',
  `dengjiriqi` date DEFAULT NULL COMMENT '登记日期',
  `beizhu` varchar(200) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`),
  UNIQUE KEY `tongjibianhao` (`tongjibianhao`)
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8 COMMENT='信息统计';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xinxitongji`
--

LOCK TABLES `xinxitongji` WRITE;
/*!40000 ALTER TABLE `xinxitongji` DISABLE KEYS */;
INSERT INTO `xinxitongji` VALUES (81,'2022-08-06 06:29:15','1111111111','基地名称1','基地面积1',1,'2022-08-06','备注1'),(82,'2022-08-06 06:29:15','2222222222','基地名称2','基地面积2',2,'2022-08-06','备注2'),(83,'2022-08-06 06:29:15','3333333333','基地名称3','基地面积3',3,'2022-08-06','备注3'),(84,'2022-08-06 06:29:15','4444444444','基地名称4','基地面积4',4,'2022-08-06','备注4'),(85,'2022-08-06 06:29:15','5555555555','基地名称5','基地面积5',5,'2022-08-06','备注5'),(86,'2022-08-06 06:29:15','6666666666','基地名称6','基地面积6',6,'2022-08-06','备注6');
/*!40000 ALTER TABLE `xinxitongji` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `yuangong`
--

DROP TABLE IF EXISTS `yuangong`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `yuangong` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `gonghao` varchar(200) NOT NULL COMMENT '工号',
  `mima` varchar(200) NOT NULL COMMENT '密码',
  `xingming` varchar(200) NOT NULL COMMENT '姓名',
  `xingbie` varchar(200) DEFAULT NULL COMMENT '性别',
  `nianling` varchar(200) DEFAULT NULL COMMENT '年龄',
  `shouji` varchar(200) DEFAULT NULL COMMENT '手机',
  `bumen` varchar(200) DEFAULT NULL COMMENT '部门',
  `tupian` varchar(200) DEFAULT NULL COMMENT '图片',
  PRIMARY KEY (`id`),
  UNIQUE KEY `gonghao` (`gonghao`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COMMENT='员工';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `yuangong`
--

LOCK TABLES `yuangong` WRITE;
/*!40000 ALTER TABLE `yuangong` DISABLE KEYS */;
INSERT INTO `yuangong` VALUES (11,'2022-08-06 06:29:15','工号1','123456','姓名1','男','年龄1','13823888881','部门1','upload/yuangong_tupian1.jpg'),(12,'2022-08-06 06:29:15','工号2','123456','姓名2','男','年龄2','13823888882','部门2','upload/yuangong_tupian2.jpg'),(13,'2022-08-06 06:29:15','工号3','123456','姓名3','男','年龄3','13823888883','部门3','upload/yuangong_tupian3.jpg'),(14,'2022-08-06 06:29:15','工号4','123456','姓名4','男','年龄4','13823888884','部门4','upload/yuangong_tupian4.jpg'),(15,'2022-08-06 06:29:15','工号5','123456','姓名5','男','年龄5','13823888885','部门5','upload/yuangong_tupian5.jpg'),(16,'2022-08-06 06:29:15','工号6','123456','姓名6','男','年龄6','13823888886','部门6','upload/yuangong_tupian6.jpg');
/*!40000 ALTER TABLE `yuangong` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `yuanliaokucun`
--

DROP TABLE IF EXISTS `yuanliaokucun`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `yuanliaokucun` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `yuanliaobianhao` varchar(200) DEFAULT NULL COMMENT '原料编号',
  `yuanliaomingcheng` varchar(200) NOT NULL COMMENT '原料名称',
  `yuanliaoleibie` varchar(200) NOT NULL COMMENT '原料类别',
  `shuliang` int(11) DEFAULT NULL COMMENT '数量',
  `yuanliaoxiangqing` longtext COMMENT '原料详情',
  `dengjiriqi` date DEFAULT NULL COMMENT '登记日期',
  `clicktime` datetime DEFAULT NULL COMMENT '最近点击时间',
  `clicknum` int(11) DEFAULT '0' COMMENT '点击次数',
  PRIMARY KEY (`id`),
  UNIQUE KEY `yuanliaobianhao` (`yuanliaobianhao`)
) ENGINE=InnoDB AUTO_INCREMENT=207 DEFAULT CHARSET=utf8 COMMENT='原料库存';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `yuanliaokucun`
--

LOCK TABLES `yuanliaokucun` WRITE;
/*!40000 ALTER TABLE `yuanliaokucun` DISABLE KEYS */;
INSERT INTO `yuanliaokucun` VALUES (201,'2022-08-06 06:29:15','1111111111','原料名称1','原料类别1',1,'原料详情1','2022-08-06','2022-08-06 14:29:15',1),(202,'2022-08-06 06:29:15','2222222222','原料名称2','原料类别2',2,'原料详情2','2022-08-06','2022-08-06 14:29:15',2),(203,'2022-08-06 06:29:15','3333333333','原料名称3','原料类别3',3,'原料详情3','2022-08-06','2022-08-06 14:29:15',3),(204,'2022-08-06 06:29:15','4444444444','原料名称4','原料类别4',4,'原料详情4','2022-08-06','2022-08-06 14:29:15',4),(205,'2022-08-06 06:29:15','5555555555','原料名称5','原料类别5',5,'原料详情5','2022-08-06','2022-08-06 14:29:15',5),(206,'2022-08-06 06:29:15','6666666666','原料名称6','原料类别6',6,'原料详情6','2022-08-06','2022-08-06 14:29:15',6);
/*!40000 ALTER TABLE `yuanliaokucun` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `yuanliaoxiaoliang`
--

DROP TABLE IF EXISTS `yuanliaoxiaoliang`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `yuanliaoxiaoliang` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `tongjibianhao` varchar(200) DEFAULT NULL COMMENT '统计编号',
  `yuanliaomingcheng` varchar(200) NOT NULL COMMENT '原料名称',
  `yuanliaoxiaoliang` int(11) DEFAULT NULL COMMENT '原料销量',
  `dengjiriqi` date DEFAULT NULL COMMENT '登记日期',
  `beizhu` varchar(200) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`),
  UNIQUE KEY `tongjibianhao` (`tongjibianhao`)
) ENGINE=InnoDB AUTO_INCREMENT=157 DEFAULT CHARSET=utf8 COMMENT='原料销量';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `yuanliaoxiaoliang`
--

LOCK TABLES `yuanliaoxiaoliang` WRITE;
/*!40000 ALTER TABLE `yuanliaoxiaoliang` DISABLE KEYS */;
INSERT INTO `yuanliaoxiaoliang` VALUES (151,'2022-08-06 06:29:15','1111111111','原料名称1',1,'2022-08-06','备注1'),(152,'2022-08-06 06:29:15','2222222222','原料名称2',2,'2022-08-06','备注2'),(153,'2022-08-06 06:29:15','3333333333','原料名称3',3,'2022-08-06','备注3'),(154,'2022-08-06 06:29:15','4444444444','原料名称4',4,'2022-08-06','备注4'),(155,'2022-08-06 06:29:15','5555555555','原料名称5',5,'2022-08-06','备注5'),(156,'2022-08-06 06:29:15','6666666666','原料名称6',6,'2022-08-06','备注6');
/*!40000 ALTER TABLE `yuanliaoxiaoliang` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `yuanliaoxinxi`
--

DROP TABLE IF EXISTS `yuanliaoxinxi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `yuanliaoxinxi` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `yuanliaobianhao` varchar(200) DEFAULT NULL COMMENT '原料编号',
  `kafeidoupinzhong` varchar(200) DEFAULT NULL COMMENT '咖啡豆品种',
  `chanliang` int(11) DEFAULT NULL COMMENT '产量',
  `weizhi` varchar(200) DEFAULT NULL COMMENT '位置',
  `dengjiriqi` date DEFAULT NULL COMMENT '登记日期',
  `yuanliaoxiangqing` longtext COMMENT '原料详情',
  PRIMARY KEY (`id`),
  UNIQUE KEY `yuanliaobianhao` (`yuanliaobianhao`)
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=utf8 COMMENT='原料信息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `yuanliaoxinxi`
--

LOCK TABLES `yuanliaoxinxi` WRITE;
/*!40000 ALTER TABLE `yuanliaoxinxi` DISABLE KEYS */;
INSERT INTO `yuanliaoxinxi` VALUES (91,'2022-08-06 06:29:15','1111111111','咖啡豆品种1',1,'位置1','2022-08-06','原料详情1'),(92,'2022-08-06 06:29:15','2222222222','咖啡豆品种2',2,'位置2','2022-08-06','原料详情2'),(93,'2022-08-06 06:29:15','3333333333','咖啡豆品种3',3,'位置3','2022-08-06','原料详情3'),(94,'2022-08-06 06:29:15','4444444444','咖啡豆品种4',4,'位置4','2022-08-06','原料详情4'),(95,'2022-08-06 06:29:15','5555555555','咖啡豆品种5',5,'位置5','2022-08-06','原料详情5'),(96,'2022-08-06 06:29:15','6666666666','咖啡豆品种6',6,'位置6','2022-08-06','原料详情6');
/*!40000 ALTER TABLE `yuanliaoxinxi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `zhichutongji`
--

DROP TABLE IF EXISTS `zhichutongji`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zhichutongji` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `tongjibianhao` varchar(200) DEFAULT NULL COMMENT '统计编号',
  `wuliaozhichu` float DEFAULT NULL COMMENT '物料支出',
  `renlizhichu` float DEFAULT NULL COMMENT '人力支出',
  `tudizulin` float DEFAULT NULL COMMENT '土地租赁',
  `chanpinjiagong` float DEFAULT NULL COMMENT '产品加工',
  `qitazhichu` float DEFAULT NULL COMMENT '其他支出',
  `zongzhichu` float DEFAULT NULL COMMENT '总支出',
  `dengjiriqi` date DEFAULT NULL COMMENT '登记日期',
  `beizhu` varchar(200) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`),
  UNIQUE KEY `tongjibianhao` (`tongjibianhao`)
) ENGINE=InnoDB AUTO_INCREMENT=177 DEFAULT CHARSET=utf8 COMMENT='支出统计';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zhichutongji`
--

LOCK TABLES `zhichutongji` WRITE;
/*!40000 ALTER TABLE `zhichutongji` DISABLE KEYS */;
INSERT INTO `zhichutongji` VALUES (171,'2022-08-06 06:29:15','1111111111',1,1,1,1,1,1,'2022-08-06','备注1'),(172,'2022-08-06 06:29:15','2222222222',2,2,2,2,2,2,'2022-08-06','备注2'),(173,'2022-08-06 06:29:15','3333333333',3,3,3,3,3,3,'2022-08-06','备注3'),(174,'2022-08-06 06:29:15','4444444444',4,4,4,4,4,4,'2022-08-06','备注4'),(175,'2022-08-06 06:29:15','5555555555',5,5,5,5,5,5,'2022-08-06','备注5'),(176,'2022-08-06 06:29:15','6666666666',6,6,6,6,6,6,'2022-08-06','备注6');
/*!40000 ALTER TABLE `zhichutongji` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `zhongzhifangan`
--

DROP TABLE IF EXISTS `zhongzhifangan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zhongzhifangan` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `fanganbiaoti` varchar(200) NOT NULL COMMENT '方案标题',
  `shiyongpinzhong` longtext COMMENT '适用品种',
  `fabushijian` date DEFAULT NULL COMMENT '发布时间',
  `fengmian` varchar(200) DEFAULT NULL COMMENT '封面',
  `fanganneirong` longtext COMMENT '方案内容',
  `clicktime` datetime DEFAULT NULL COMMENT '最近点击时间',
  `clicknum` int(11) DEFAULT '0' COMMENT '点击次数',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8 COMMENT='种植方案';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zhongzhifangan`
--

LOCK TABLES `zhongzhifangan` WRITE;
/*!40000 ALTER TABLE `zhongzhifangan` DISABLE KEYS */;
INSERT INTO `zhongzhifangan` VALUES (71,'2022-08-06 06:29:15','方案标题1','适用品种1','2022-08-06','upload/zhongzhifangan_fengmian1.jpg','方案内容1','2022-08-06 14:29:15',1),(72,'2022-08-06 06:29:15','方案标题2','适用品种2','2022-08-06','upload/zhongzhifangan_fengmian2.jpg','方案内容2','2022-08-06 14:29:15',2),(73,'2022-08-06 06:29:15','方案标题3','适用品种3','2022-08-06','upload/zhongzhifangan_fengmian3.jpg','方案内容3','2022-08-06 14:29:15',3),(74,'2022-08-06 06:29:15','方案标题4','适用品种4','2022-08-06','upload/zhongzhifangan_fengmian4.jpg','方案内容4','2022-08-06 14:29:15',4),(75,'2022-08-06 06:29:15','方案标题5','适用品种5','2022-08-06','upload/zhongzhifangan_fengmian5.jpg','方案内容5','2022-08-06 14:29:15',5),(76,'2022-08-06 06:29:15','方案标题6','适用品种6','2022-08-06','upload/zhongzhifangan_fengmian6.jpg','方案内容6','2022-08-06 14:29:15',6);
/*!40000 ALTER TABLE `zhongzhifangan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `zhongzhiguocheng`
--

DROP TABLE IF EXISTS `zhongzhiguocheng`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zhongzhiguocheng` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `dengjibianhao` varchar(200) DEFAULT NULL COMMENT '登记编号',
  `zhongzhipinzhong` varchar(200) DEFAULT NULL COMMENT '种植品种',
  `zhongzhishuliang` int(11) DEFAULT NULL COMMENT '种植数量',
  `zhongzhifangshi` varchar(200) DEFAULT NULL COMMENT '种植方式',
  `shipin` varchar(200) DEFAULT NULL COMMENT '视频',
  `dengjiriqi` date DEFAULT NULL COMMENT '登记日期',
  `beizhu` varchar(200) DEFAULT NULL COMMENT '备注',
  `gonghao` varchar(200) DEFAULT NULL COMMENT '工号',
  `xingming` varchar(200) DEFAULT NULL COMMENT '姓名',
  PRIMARY KEY (`id`),
  UNIQUE KEY `dengjibianhao` (`dengjibianhao`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8 COMMENT='种植过程';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zhongzhiguocheng`
--

LOCK TABLES `zhongzhiguocheng` WRITE;
/*!40000 ALTER TABLE `zhongzhiguocheng` DISABLE KEYS */;
INSERT INTO `zhongzhiguocheng` VALUES (51,'2022-08-06 06:29:15','1111111111','种植品种1',1,'灌溉','','2022-08-06','备注1','工号1','姓名1'),(52,'2022-08-06 06:29:15','2222222222','种植品种2',2,'灌溉','','2022-08-06','备注2','工号2','姓名2'),(53,'2022-08-06 06:29:15','3333333333','种植品种3',3,'灌溉','','2022-08-06','备注3','工号3','姓名3'),(54,'2022-08-06 06:29:15','4444444444','种植品种4',4,'灌溉','','2022-08-06','备注4','工号4','姓名4'),(55,'2022-08-06 06:29:15','5555555555','种植品种5',5,'灌溉','','2022-08-06','备注5','工号5','姓名5'),(56,'2022-08-06 06:29:15','6666666666','种植品种6',6,'灌溉','','2022-08-06','备注6','工号6','姓名6');
/*!40000 ALTER TABLE `zhongzhiguocheng` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `zhongzhishuju`
--

DROP TABLE IF EXISTS `zhongzhishuju`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `zhongzhishuju` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `dengjibianhao` varchar(200) DEFAULT NULL COMMENT '登记编号',
  `zhongzhipinzhong` varchar(200) DEFAULT NULL COMMENT '种植品种',
  `turangshidu` varchar(200) DEFAULT NULL COMMENT '土壤湿度',
  `turangsuanjiandu` varchar(200) DEFAULT NULL COMMENT '土壤酸碱度',
  `turangwendu` varchar(200) DEFAULT NULL COMMENT '土壤温度',
  `turangdaodianlv` varchar(200) DEFAULT NULL COMMENT '土壤导电率',
  `guangzhaoqiangdu` varchar(200) DEFAULT NULL COMMENT '光照强度',
  `dengjiriqi` date DEFAULT NULL COMMENT '登记日期',
  `beizhu` varchar(200) DEFAULT NULL COMMENT '备注',
  `gonghao` varchar(200) DEFAULT NULL COMMENT '工号',
  `xingming` varchar(200) DEFAULT NULL COMMENT '姓名',
  PRIMARY KEY (`id`),
  UNIQUE KEY `dengjibianhao` (`dengjibianhao`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8 COMMENT='种植数据';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zhongzhishuju`
--

LOCK TABLES `zhongzhishuju` WRITE;
/*!40000 ALTER TABLE `zhongzhishuju` DISABLE KEYS */;
INSERT INTO `zhongzhishuju` VALUES (61,'2022-08-06 06:29:15','1111111111','种植品种1','土壤湿度1','土壤酸碱度1','土壤温度1','土壤导电率1','光照强度1','2022-08-06','备注1','工号1','姓名1'),(62,'2022-08-06 06:29:15','2222222222','种植品种2','土壤湿度2','土壤酸碱度2','土壤温度2','土壤导电率2','光照强度2','2022-08-06','备注2','工号2','姓名2'),(63,'2022-08-06 06:29:15','3333333333','种植品种3','土壤湿度3','土壤酸碱度3','土壤温度3','土壤导电率3','光照强度3','2022-08-06','备注3','工号3','姓名3'),(64,'2022-08-06 06:29:15','4444444444','种植品种4','土壤湿度4','土壤酸碱度4','土壤温度4','土壤导电率4','光照强度4','2022-08-06','备注4','工号4','姓名4'),(65,'2022-08-06 06:29:15','5555555555','种植品种5','土壤湿度5','土壤酸碱度5','土壤温度5','土壤导电率5','光照强度5','2022-08-06','备注5','工号5','姓名5'),(66,'2022-08-06 06:29:15','6666666666','种植品种6','土壤湿度6','土壤酸碱度6','土壤温度6','土壤导电率6','光照强度6','2022-08-06','备注6','工号6','姓名6');
/*!40000 ALTER TABLE `zhongzhishuju` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-06 14:37:11
