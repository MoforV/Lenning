const multer=require('@koa/multer')
const COS = require('cos-nodejs-sdk-v5');

var cos = new COS({
    SecretId: 'AKIDwg9LIxMTKsAAuNYS5SYMtAAtKVP2QYQ2',
    SecretKey: 'LPDjywe5GAm8E4cuwg9MIwJWS7VcSP5U',
	Protocol:'https:'
});
let Bucket='zmy20220221-moncytea-1309715269'
let Region='ap-nanjing'
let cosfun=function(filename,path){
	// console.log(filename)
	// console.log(path)
	return new Promise((resolve,reject)=>{
		cos.uploadFile({
			Bucket,
			Region,
			Key:'MoncyTea/'+filename,//K是大写的
			FilePath: path, 
		})
		.then(res=>{
			resolve(res.Location)
		})
		.catch(err=>{
			reject(err)
		})
	})
}
//二进制上传
let buffer=function(filename,path){
	
	return new Promise((resolve,reject)=>{
		cos.putObject({
			Bucket,
			Region,
			Key:'MoncyTea/'+filename,//K是大写的
			Body: Buffer.from(path), 
		})
		.then(res=>{
			resolve(res.Location)
		})
		.catch(err=>{
			reject(err)
		})
	})
}

//配置上传的文件1.所在的目录 2.更改文件名
const storage=multer.diskStorage({//磁盘存储引擎方法
	destination:(req,file,cb)=>{//存储前端传来的文件
		cb(null,'upload/image')
	},
	 filename:(req, file, cb)=> {
	    console.log(file)
		//防止文件重名更改前缀
		let fileFormat=(file.originalname).split(".")
		//Date.now()时间戳
		let num=`${Date.now()}-${Math.floor(Math.random(0,1)*10000000)}${"."}${fileFormat[fileFormat.length-1]}`
		cb(null,num)
	  }
})
const upload = multer({storage})
module.exports={upload,cosfun,buffer}