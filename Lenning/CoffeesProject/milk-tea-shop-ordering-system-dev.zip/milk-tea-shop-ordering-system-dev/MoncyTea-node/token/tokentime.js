module.exports={
	security:{
		secretkey:"abcdefg",//参与加密token的值
		expiresIn:60*60*24*3//过期时间
	}
}
