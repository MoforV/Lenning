<template>
    <div class="notfound">
      <img src="../../../static/404.gif" alt="">
    </div>
</template>
<style scoped>
.notfound{
    width: 100%;
    height: 100%;
    overflow: hidden;
}
.notfound img{
    width: 100%;
    height: 100%;
}
</style>
