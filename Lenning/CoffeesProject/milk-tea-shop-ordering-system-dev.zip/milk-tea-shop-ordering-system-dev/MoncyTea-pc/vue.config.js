module.exports = {
  publicPath:'./'
}