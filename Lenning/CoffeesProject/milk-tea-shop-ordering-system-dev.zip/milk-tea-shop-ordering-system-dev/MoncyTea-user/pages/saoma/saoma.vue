<template>
	<!-- view===div -->
	
</template>

<script>
</script>

<style>
	page{
		background-image: url('https://diancan-1252107261.cos.accelerate.myqcloud.com/mp3/saoma-beijing.jpg');
		background-attachment: fixed;
		background-repeat: no-repeat;
		background-size: cover;
	}
</style>
