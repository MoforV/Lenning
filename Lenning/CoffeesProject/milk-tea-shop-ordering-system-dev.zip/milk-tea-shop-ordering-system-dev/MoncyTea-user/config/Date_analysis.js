//计算当天的销售额
const db = wx.cloud.database()
const _=db.command
const seven=db.collection('seven_day_sales')

class analysis{
	constructor() {
	    
	}
	//time:当天时间，sales_valume：提交的饮品总价
	async sameday(time,sales_valume){
		try{
			let query =await seven.where({time}).get()
			console.log(query)
			if(query.data.length==0){
				await seven.add({data:{time,sales_valume}})
			}else{
				let total_amount=Number(query.data[0].sales_valume)+sales_valume
				let final_data=parseFloat((total_amount).toFixed(10)) //防止浮点数精度丢失问题
				await seven.doc(query.data[0]._id).update({
					data:{
						sales_valume:final_data
					}
				})
			}
		}catch(e){
			//TODO handle the exception
			throw '错误'
		}
	}
}

export{analysis}