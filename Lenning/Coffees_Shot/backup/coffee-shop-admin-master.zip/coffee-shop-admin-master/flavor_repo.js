var flavors = {
    "1" : {key : "1", name : "Espresso", price : "285Rs"},
    "2" : {key : "2", name : "Cappuccino", price : "310Rs"},
    "3" : {key : "3", name : "Americano", price : "290Rs"},
    "4" : {key : "4", name : "Caffe Latte", price : "415Rs"},
    "5" : {key : "5", name : "Caf au Lait", price : "395Rs"},
    "6" : {key : "6", name : "Mochachino", price : "520Rs"},
    "7" : {key : "7", name : "Caramel Macchiato", price : "495Rs"}
};

module.exports = {
    flavors : flavors
}