# coffee-shop-admin
Sample admin panel UI for a coffee shop using NodeJs

### Prerequisites
* NodeJs v0.12.2

### How to run
* Open command prompt or terminal(If Linux)
* Go to coffee-shop-admin
* Enter following command

```
npm install #To download dependencies, this is for first time build only
node bin/www
```

* To see web page go to localhost:3000
